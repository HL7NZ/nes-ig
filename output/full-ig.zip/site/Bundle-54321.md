# enrolment-nomination-request-message-2 - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **enrolment-nomination-request-message-2**

## Example Bundle: enrolment-nomination-request-message-2



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "54321",
  "type" : "message",
  "timestamp" : "2023-05-14T11:15:33+10:00",
  "entry" : [
    {
      "fullUrl" : "12345",
      "resource" : {
        "resourceType" : "MessageHeader",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_null\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader </b></p><p><b>event</b>: <a href=\"https://common-ig.hip.digital.health.nz/site/CodeSystem-nes-event-type-1.0.html#nes-event-type-1.0-FLS_ENROLMENT_NOMINATION\">NES Event Type: FLS_ENROLMENT_NOMINATION</a> (GP Enrolment Nomination)</p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td>pmsfacid</td><td>edi123</td></tr></table><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Software</b></td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td>HSA3333</td><td><a href=\"http:///example.com\">http:///example.com</a></td></tr></table><p><b>focus</b>: </p><ul><li><a href=\"Bundle-11223344.html#https-//api.hip-uat.digital.health.nz/fhir/nhi/v1/Patient/ZKC4633\">Baby of Jane Aufderhar  Female, DoB: 2023-05-25 ( https://standards.digital.health.nz/ns/nhi-id#NHI#ZKC4633 (use: official, ))</a></li><li><a href=\"Bundle-11223344.html#RelatedPerson_ZJM9397\">RelatedPerson Mary Jones </a></li></ul></div>"
        },
        "eventCoding" : {
          "system" : "https://standards.digital.health.nz/ns/nes-event-type",
          "code" : "FLS_ENROLMENT_NOMINATION"
        },
        "destination" : [
          {
            "name" : "pmsfacid",
            "endpoint" : "edi123"
          }
        ],
        "source" : {
          "software" : "HSA3333",
          "endpoint" : "http:///example.com"
        },
        "focus" : [
          {
            "reference" : "https://api.hip-uat.digital.health.nz/fhir/nhi/v1/Patient/ZKC4633"
          },
          {
            "reference" : "RelatedPerson/ZJM9397"
          }
        ]
      }
    },
    {
      "fullUrl" : "https://api.hip-uat.digital.health.nz/fhir/nhi/v1/Patient/ZKC4633",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "ZKC4633",
        "meta" : {
          "profile" : ["NHIPatient"]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_ZKC4633\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient ZKC4633</b></p><a name=\"ZKC4633\"> </a><a name=\"hcZKC4633\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <code>NHIPatient</code></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Baby of Jane Aufderhar  Female, DoB: 2023-05-25 ( https://standards.digital.health.nz/ns/nhi-id#NHI#ZKC4633 (use: official, ))</p><hr/></div>"
        },
        "identifier" : [
          {
            "use" : "official",
            "system" : "https://standards.digital.health.nz/ns/nhi-id",
            "value" : "ZKC4633"
          }
        ],
        "name" : [
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-preferred",
                "valueBoolean" : true
              }
            ],
            "family" : "Aufderhar",
            "given" : ["Baby of Jane"]
          }
        ],
        "gender" : "female",
        "birthDate" : "2023-05-25"
      }
    },
    {
      "fullUrl" : "RelatedPerson/ZJM9397",
      "resource" : {
        "resourceType" : "RelatedPerson",
        "id" : "ZJM9397",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"RelatedPerson_ZJM9397\"> </a><p class=\"res-header-id\"><b>Generated Narrative: RelatedPerson ZJM9397</b></p><a name=\"ZJM9397\"> </a><a name=\"hcZJM9397\"> </a><p><b>identifier</b>: NHI/ZJM9397 (use: official, )</p><p><b>patient</b>: <a href=\"Bundle-11223344.html#https-//api.hip-uat.digital.health.nz/fhir/nhi/v1/Patient/ZKC4633\">Baby of Jane Aufderhar  Female, DoB: 2023-05-25 ( https://standards.digital.health.nz/ns/nhi-id#NHI#ZKC4633 (use: official, ))</a></p><p><b>relationship</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-RoleCode MTH}\">mother</span></p><p><b>name</b>: Mary Jones </p></div>"
        },
        "identifier" : [
          {
            "use" : "official",
            "system" : "https://standards.digital.health.nz/ns/nhi-id",
            "value" : "ZJM9397"
          }
        ],
        "patient" : {
          "reference" : "https://api.hip-uat.digital.health.nz/fhir/nhi/v1/Patient/ZKC4633"
        },
        "relationship" : [
          {
            "coding" : [
              {
                "system" : "http://terminology.hl7.org/CodeSystem/v3-RoleCode",
                "code" : "MTH"
              }
            ]
          }
        ],
        "name" : [
          {
            "extension" : [
              {
                "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-preferred",
                "valueBoolean" : true
              }
            ],
            "family" : "Jones",
            "given" : ["Mary"]
          }
        ]
      }
    }
  ]
}

```
