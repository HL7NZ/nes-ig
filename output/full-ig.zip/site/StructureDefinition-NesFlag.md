# NesFlag - New Zealand NES IG v1.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NesFlag**

## Resource Profile: NesFlag 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org.nz/fhir/StructureDefinition/NesFlag | *Version*:1.5.0 |
| Active as of 2026-05-11 | *Computable Name*:NesFlag |

 
Used to flag NES related information 

**Usages:**

* Examples for this Profile: [Bundle/FL101](Bundle-FL101.md) and [Flag/FL100](Flag-FL100.md)
* CapabilityStatements using this Profile: [CapabilityStatement[http://hl7.org.nz/fhir/ig/nes/CapabilityStatement/NESCapabilityStatement|1.5.0]](CapabilityStatement-NESCapabilityStatement.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.org.nz.fhir.ig.nes|current/StructureDefinition/NesFlag)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-NesFlag.csv), [Excel](StructureDefinition-NesFlag.xlsx), [Schematron](StructureDefinition-NesFlag.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "NesFlag",
  "url" : "http://hl7.org.nz/fhir/StructureDefinition/NesFlag",
  "version" : "1.5.0",
  "name" : "NesFlag",
  "title" : "NesFlag",
  "status" : "active",
  "date" : "2026-05-11T04:48:39+00:00",
  "publisher" : "Te Whatu Ora",
  "contact" : [{
    "name" : "Te Whatu Ora",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:integration@health.govt.nz"
    }]
  }],
  "description" : "Used to flag NES related information",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Flag",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Flag",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Flag",
      "path" : "Flag"
    },
    {
      "id" : "Flag.extension",
      "path" : "Flag.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      }
    },
    {
      "id" : "Flag.extension:flag-detail",
      "path" : "Flag.extension",
      "sliceName" : "flag-detail",
      "short" : "What the flag is about",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["http://hl7.org/fhir/StructureDefinition/flag-detail"]
      }]
    },
    {
      "id" : "Flag.extension:flag-detail.value[x]",
      "path" : "Flag.extension.value[x]",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/RelatedPerson"]
      }]
    },
    {
      "id" : "Flag.category",
      "path" : "Flag.category",
      "max" : "0"
    },
    {
      "id" : "Flag.code",
      "path" : "Flag.code",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/nes-flag-type"
      }
    },
    {
      "id" : "Flag.subject",
      "path" : "Flag.subject",
      "short" : "Who the flag is about",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
      }]
    },
    {
      "id" : "Flag.encounter",
      "path" : "Flag.encounter",
      "max" : "0"
    },
    {
      "id" : "Flag.author",
      "path" : "Flag.author",
      "max" : "0"
    }]
  }
}

```
