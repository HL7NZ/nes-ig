# Artifacts Summary - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

## Artifacts Summary

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Behavior: Capability Statements 

The following artifacts define the specific capabilities that different types of systems are expected to have in order to comply with this implementation guide. Systems conforming to this implementation guide are expected to declare conformance to one or more of the following capability statements.

| | |
| :--- | :--- |
| [NESCapabilityStatement](CapabilityStatement-NESCapabilityStatement.md) | NES FHIR Capabilities |

### Behavior: Message Definitions 

These define the types of messages that can be sent and/or received by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [EnrolmentNominationRequestMessageDefinition](MessageDefinition-EnrolmentNominationRequestMessageDefinition.md) | Defines the message used to request an enrolment |
| [EnrolmentNominationResponseMessageDefinition](MessageDefinition-EnrolmentNominationResponseMessageDefinition.md) | Defines the message used to respond to a request for an enrolment |

### Structures: Resource Profiles 

These define constraints on FHIR resources for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [EnrolmentNominationResponse](StructureDefinition-EnrolmentNominationResponse.md) | Adds additional, NES specific extensions |
| [NES Enrolment](StructureDefinition-NesEnrolment.md) | Adds additional, NES specific extensions for enrolments |
| [NES Entitlements](StructureDefinition-NesEntitlement.md) | The coverage resource contains information related to Patient entitlements |
| [NES Patient](StructureDefinition-NesPatient.md) | A minimal profile of NzPatient, containing just enough information to validate a patient's NHI for the purposes of enrolment |
| [NES PractitionerRole](StructureDefinition-NesPractitionerRole.md) | A minimal profile of PractitionerRole, which just contains references to the enrolling facility, organisation and practitioner |
| [NesEncounter](StructureDefinition-NesEncounter.md) | Restricts Encounter to the elemrnts need to describe an NES Enrolment qualified Encounter |

### Structures: Extension Definitions 

These define constraints on FHIR data types for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Enrolment_encounter](StructureDefinition-enrolment-encounter.md) | The last qualified encounter foe this enrolment |
| [Enrolment_expiry_date](StructureDefinition-enrolment-expiry-date.md) | The enrolment expiry date |
| [Enrolment_owner_org](StructureDefinition-enrolment-owner-org.md) | Org that creates the enrolment |
| [Nes_enrolment_termination_reason](StructureDefinition-nes-enrolment-termination-reason.md) | NES Enrolment Termination Reason Code |
| [Reenrolment_expiry_date](StructureDefinition-reenrolment-date.md) | The re-enrolment date |

### Example: Example Instances 

These are example instances that show what data produced and consumed by systems conforming with this implementation guide might look like.

| | |
| :--- | :--- |
| [do-not-populate-id](EpisodeOfCare-do-not-populate-id.md) | Example enrolment create request payload |
| [enrolment-1](EpisodeOfCare-EN667788899.md) | Example enrolment |
| [enrolment-2-ended](EpisodeOfCare-EN12349876.md) | Example enrolment update request with termination reason |
| [enrolment-bundle1](Bundle-EN88776655.md) | Example enrolment search response (active enrolments for NHI) |
| [enrolment-nomination-request-error-response-1](OperationOutcome-enrolment-nomination-request-error-response-1.md) | Example of a synchronous 422 error response to a enrolment nomination request message |
| [enrolment-nomination-request-message-1](Bundle-11223344.md) | Example enrolment nomination request message |
| [enrolment-nomination-request-message-2](Bundle-54321.md) | Example of a minimal enrolment nomination request message sent by Whaihua to NES which will be enriched by NES before being forwarded to the HealthLink AIR broker |
| [enrolment-nomination-response-error-response-1](OperationOutcome-enrolment-nomination-response-error-response-1.md) | Example of a synchronous 40x error response to a enrolment nomination request message |
| [enrolment-nomination-response-message-1](Bundle-34567.md) | Example enrolment nomination request message |
| [enrolment-nomination-response-message-2](Bundle-6789.md) | Example enrolment nomination error response message |
| [entitlement-1](Coverage-EN667788899.md) | Example CSC entitlement |
| [entitlement-2](Coverage-EN5544332211.md) | Example CSC dependant entitlement |
| [entitlement-3](Coverage-entitlement-3.md) | Example create payload for CSC entitlement |
| [entitlement-4](Coverage-ENPSC12345.md) | Example PSC entitlement |

