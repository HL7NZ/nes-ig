# Create Enrolment - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* **Create Enrolment**

## Create Enrolment

### Create Enrolment for Patient

The Create Enrolment operation is initiated by a user who needs to create a new Enrolment with a health provider for the provision of a health service to a patient.

#### Create Enrolment processing steps:

1. A FHIR Client sends a POST request to the NES**EpisodeOfCare**endpoint with a payload containing the NesEnrolment resource to be created, excluding ids
1. The request is validated - ALT: Validation failure. Operation Outcome resource returned
1. The Enrolment is created in the EEE database and an ID is assigned
1. A newly created NESEnrolment, including its ID, is returned to the client

#### Create Enrolment Request Example

[create Enrolment request](CreateEnrolmentRequestExample.md)

#### Behaviour

* FHIR Create Enrolment operation received by the system
* Requester identity checked to make sure they are valid and have correct permission set.
* Enrolment record is validated.
* The patient identity is validated.
* The request is checked against existing enrolment records for the patient to make sure the changes requested complies with the relevant enrolment Business and Attribute Rules.
* If all the attributes / items in the Enrolment record are correct 
* A new enrolment record is created in NES with the details populated in the request.
* If required any enrolments are ended.
 
* If checks result in an error at any point, processing will stop and an Operation Outcome resource returned.
* If the request results in an existing Patient Provider enrolment ending, a notification will be created. 
* Organisations use the Common ‘Get Notifications’ request to check for new notifications of changes.
* We won’t send a notification if the enrolment is with the org that actions the request.
 

#### Business Rules

* A Create Enrolment request must include: 
* A valid enrolling organisation (HPI-Organisation-id),
* A valid service facility (HPI-Facility-id) (WCTO excluded).
* Enrolment status
* Enrolment type, and
* Contained Patient resource
 
* A Create Enrolment request may include a valid practitioner (HPI-person-id / CPN)
* A Create Enrolment request must not include: 
* id or identiter (the id = identifier and is set by the service)
* qualified encounter
* re-enrolment date
* expiry date (This is set by the service 
* FLS: 
* Nomination (future scope).
* Enrol (set to three years from creation date).
* Pre-enrol (set to three months from creation date).
 
* FLS-NF (does not expire / set to a constant)
* LMC (set to 6 weeks from baby's birthdate)
* WCTP (set to the child's 5th birthday)
 
* owning Organisation (set by the service to the hpi-Organisation-id of the requestor)
* termination reason code
* period 
* start (set by the service to the operation date)
* end (only set when a record is ended)
 
 
* The Contained Patient resource must be a valid patient that includes at minimum the: 
* Live NHI
* Patient name
* Patient date of birth
 
* A request must not enrol a Patient with a Provider for a Health Service when an active enrolment for the specific Health Service exists for that patient with that Provider.
* The enrolment start date will be the date the request is processed to create the enrolment.

**FLS Specific Rules**

* A Patient must not be pre-enrolled for Health Service if an active enrolment exists for that Health Service for that patient.
* A request to enrol a patient for a health service must not be actioned if an enrolment (enrolled or pre-enrolled) has already been accepted on that date.
* A Patient must have a maximum of one active enrolment (enrolled or pre-enrolled) with a GP / PHO for Primary Care.
* A Patient must be less than three months old at the date of enrolment to pre-enrol with a GP Practice / PHO.

### Create Enrolment Errors

* Error Scenario: Missing HPI-Organisation-id in request
  * Error Code: EM07201
  * Error Message: HPI-Organisation-id is a required field
  * HTTP Status code: **422 Unprocessable entity**
* Error Scenario: Missing HPI-Facility-id in request
  * Error Code: EM07201
  * Error Message: HPI-Facility-id is a required field
  * HTTP Status code: **422 Unprocessable entity**
* Error Scenario: Missing Enrolment status in request
  * Error Code: EM07201
  * Error Message: Enrolment status is a required field
  * HTTP Status code: **422 Unprocessable entity**
* Error Scenario: Missing Enrolment type in request
  * Error Code: EM07201
  * Error Message: Enrolment type is a required field
  * HTTP Status code: **422 Unprocessable entity**
* Error Scenario: Missing Patient resource in request
  * Error Code: EM07201
  * Error Message: Patient resource is a required field
  * HTTP Status code: **422 Unprocessable entity**
* Error Scenario: NHI provied is dormant
  * Error Code: EM02004
  * Error Message: The NHI Identifier provided is dormant. This record cannot be updated
  * HTTP Status code: **422 Unprocessable entity**
* Error Scenario: Patient identity information does not match Patient NHI supplied
  * Error Code: EM02008
  * Error Message: The Patient identity information does not match Patient NHI supplied
  * HTTP Status code: **422 Unprocessable entity**
* Error Scenario: NHI number supplied supplied cannot be found.
  * Error Code: EM02002
  * Error Message: NHI number supplied supplied cannot be found.
  * HTTP Status code: **422 Unprocessable entity**
* Error Scenario: HPI-Organisation-id supplied cannot be found.
  * Error Code: EM02002
  * Error Message: HPI-Organisation-id supplied cannot be found.
  * HTTP Status code: **422 Unprocessable entity**
* Error Scenario: HPI-Facility-id supplied cannot be found.
  * Error Code: EM02002
  * Error Message: HPI-Facility-id supplied cannot be found.
  * HTTP Status code: **422 Unprocessable entity**
* Error Scenario: hpi-person-id (CPN) supplied cannot be found.
  * Error Code: EM02002
  * Error Message: hpi-person-id (CPN) supplied cannot be found.
  * HTTP Status code: **422 Unprocessable entity**
* Error Scenario: An enrolment for <1> already exists for this patient with the requested organisation
  * Error Code: EM11003
  * Error Message: An enrolment already exists for this patient with the requested organisation
  * HTTP Status code: **422 Unprocessable entity**
* Error Scenario: An enrolment has already been recorded for this patient today
  * Error Code: EM11006
  * Error Message: An enrolment has already been recorded for this patient today
  * HTTP Status code: **422 Unprocessable entity**
* Error Scenario: A patient must not have more than one active enrolment for a health service
  * Error Code: EM11005
  * Error Message: A patient must not have more than one active enrolment for a health service
  * HTTP Status code: **422 Unprocessable entity**
* Error Scenario: This patient is older than three months, and cannot be pre-enrolled
  * Error Code: EM11007
  * Error Message: This patient is older than three months, and cannot be pre-enrolled
  * HTTP Status code: **422 Unprocessable entity**

