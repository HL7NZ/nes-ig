# Search Flag - New Zealand NES IG v1.5.0

* [**Table of Contents**](toc.md)
* **Search Flag**

## Search Flag

### Search NesFlags for Patient

This is used to get all Nes Flags for a patient

#### Search Nes Flags for Patient processing steps:

1. A FHIR Client sends a GET request to the NES**Flag**endpoint with the 'subject' query parameter specifying the patient's NHI number
1. The request is validated - ALT: Validation failure. Operation Outcome resource returned
1. NES Flags for this NHI are retrieved from the NES database
1. A bundle of NESFlags is returned to the client - ALT: Empty bundle returned

#### Search Flags Response Example

[get-enrolment-response-message-1](Bundle-FL101.json.md)

#### Business Rules

1. A Flag search request must include a valid nhi-id

### Get and Search AllergyIntolerance for Patient Business Rules and Errors

* Business Rule: NHI number is a required search parameter
  * HTTP error: 400 Bad request
  * EM error: 
  * Codesystem displayname: 
  * Additional description: 
* Business Rule: The subject parameter must be a valid nhi-id
  * HTTP error: 404 Not found
  * EM error: EM02002
  * Codesystem displayname: Cannot be found
  * Additional description: The NHI is invalid or does not exist

