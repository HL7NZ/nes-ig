# Create Entitlement - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* **Create Entitlement**

## Create Entitlement

### Create Entitlement Overview

This operation is used to create a patient's entitlement for subsidised healthcare.

This operation is used to create an entitlement for:

* Community services card holders (CSC)
* Pharmaceutical subsidy card holders (PSC)

#### Additional information

##### CSC

* The create CSC operation should be used when: 
* a CSC entitlement is not returned with a search of the entitlements service however a person presents with a CSC. In this scenario the NHI match service hasn't been able to match an NHI to a CSC provided by MSD. The create matches the NHI with the CSC information provided by MSD and creates the entitlement. Most CSC entitlements are automatically created when CSC details are recieved.
* A CSC-dependent entitlement is not returned with a search of the entitlements service for a [dependent child of a community services card holder](https://www.tewhatuora.govt.nz/for-health-providers/claims-provider-payments-and-entitlements/community-services-card/). In this case the create operation is used to create and entitlement for the dependent child. The dependent childs CSC entitlement will have the same card number as the parent. The FHIR service uses the relationship attributre to denote a dependent card holder.
 

##### PSC

* The create PSC operation should be used when an individual or family unit is eligible to recieve a PSC and no PSC entitlement is returned with a search of the entitlements service.
* When creating a PSC the entitlements service will automatically generate a PSC number (identifier) for an individual or the first member of the family unit. For each subsequent member of the family unit, the PSC number (identifier) provided by the entitlement service should be included in the create operation. This will result in all members of the family have the same card number (Not they will all have their own entitlements and therefore have individual entitlement IDs (Coverage.id)).

**Create Entitlement processing steps:**

1. The user inputs details required to create the entitlement.
1. The integrating application sends a POST request to the NES**Coverage**endpoint with a payload containing the NesEntitlement resource to be created.
1. The request is validated - ALT: Validation failure. Operation Outcome resource returned
1. The Entitlement is created in the database and an ID is assigned.
1. A newly created NesEntitlement, including its ID, is returned to the client

### Create Entitlement Request Examples

[create CSC Entitlement request](createCSCExample.md)

[create PSC Entitlement request](createPSCExample.md)

### Create entitlement rules and errors

#### Create CSC (community services card) entitlement rules and errors

* Rule: A create CSC entitlement request must include:* type of entitlement
* beneficiary (NHI number of the patient)
* identifier (the entitlement card number)
* contained Patient resource
* organisation approving the entitlement (payor)
* status

  * Error code: * EM07201

  * Error description: * Is a required field

  * Error text: * type is a required field
* beneficiary is a required field
* identifier is a required field
* contained patient is a required field
* payor is a required field
* status is a required field

  * Http code: * 400 Bad request

* Rule: The contained patient must match Entitlement beneficiary, be alive, and validate with the National Health Index
  * Error code: * EM02008
* EM99999
* EM99999

  * Error description: * The patient identity information supplied does not match the patient identity information in the NHI
* N/A
* N/A

  * Error text: * The patient identity information supplied does not match the patient identity information in the NHI.
* 'If the resource is contained in another resource, it SHALL be referred to from elsewhere in the resource or SHALL refer to the containing resource' 'If the resource is contained in another resource, it SHALL be referred to from elsewhere in the resource or SHALL refer to the containing resource'
* Patient NHI is required

  * Http code: * 422 Unprocessable Entity
* 400 Bad request
* 400 Bad request

* Rule: A request to create an entitlement can be made against any valid NHI Identifier (live or dormant) for that patient.
  * Error code: * EM02002

  * Error description: * Cannot be found

  * Error text: * NHI number supplied cannot be found

  * Http code: * 404 Not found

* Rule: A Create Patient entitlement request must include a valid CSC Card Number
  * Error code: * EM12006

  * Error description: * The CSC Card Number must be known to Te Whatu Ora

  * Error text: * The CSC Card Number must be known to MoH (Te Whatu Ora)

  * Http code: * 400 Bad request

* Rule: A Patient can only be linked to 1 active Entitlement type i.e. CSC or CSCDependent
  * Error code: * EM12001

  * Error description: * The patient cannot have both CSC and CSCDependent Entitlements active at the same time

  * Error text: * The patient cannot have both CSC and CSCDependent Entitlements active at the same time.

  * Http code: * 400 Bad request

* Rule: A Patient can have a maximum of one Active CSC Entitlement.
  * Error code: * EM12002

  * Error description: * The patient cannot have more than one active CSC Entitlement.

  * Error text: * The patient cannot have more than one active CSC Entitlement.

  * Http code: * 400 Bad request

* Rule: A CSC Entitlement can only be associated to one (non-dependent) Patient
  * Error code: * EM12003

  * Error description: * The CSC Entitlement is already assigned to another patient

  * Error text: * The CSC Entitlement is already assigned to another patient

  * Http code: * 400 Bad request

* Rule: A patient can have multiple CSC dependent entitlements
  * Error code: 
  * Error description: 
  * Error text: 
  * Http code: 
* Rule: A CSC Dependent entitlement can only be created for a person 18 or younger
  * Error code: * EM12016

  * Error description: * The patient is not a valid age to be a CSC Dependent.

  * Error text: * The patient is not a valid age to be a CSC Dependent.

  * Http code: * 400 Bad request

* Rule: PSC Payor must be set to Te Whatu Ora (Org ID - G0K357-H)
  * Error code: * EM12029

  * Error description: * Invalid Payor

  * Error text: * Invalid Payor

  * Http code: * 400 Bad request


#### Create PSC (pharmaceutical subsidy card) entitlement rules and errors

* Rule: A create PSC entitlement request must include:* type of entitlement
* beneficiary (NHI number of the patient)
* contained Patient resource
* organisation approving the entitlement (payor)
* status
* start date (period start)

  * Error code: * EM07201

  * Error description: * Is a required field

  * Error text: * type is a required field
* beneficiary is a required field
* contained patient is a required field
* payor is a required field
* status is a required field
* period start is a required field

  * Http code: * 400 Bad request

* Rule: A Create PSC Entitlement request may include the identifier (the entitlement card number).
  * Error code: * EM12006

  * Error description: * Card Number must be known to Te Whatu Ora

  * Error text: * The PSC Card Number must be known to Te Whatu Ora

  * Http code: * 400 Bad request

* Rule: The contained patient must match Entitlement beneficiary, and validate with the National Health Index
  * Error code: * EM02008
* EM99999
* EM99999

  * Error description: * The patient identity information supplied does not match the patient identity information in the NHI.
* N/A
* N/A

  * Error text: * The patient identity information supplied does not match the patient identity information in the NHI.
* 'If the resource is contained in another resource, it SHALL be referred to from elsewhere in the resource or SHALL refer to the containing resource' 'If the resource is contained in another resource, it SHALL be referred to from elsewhere in the resource or SHALL refer to the containing resource'
* Patient NHI is required

  * Http code: * 422 Unprocessable Entity
* 400 Bad request
* 400 Bad request

* Rule: Cannot create and entitlement for a deceased person
  * Error code: * EM12022

  * Error description: * Cannot create or update entitlement for deceased person

  * Error text: * Cannot create or update entitlement for deceased person

  * Http code: * 400 Bad request

* Rule: The PSC card number must be 1-16 numeric characters, with no leading zeros
  * Error code: * EM12023

  * Error description: * Invalid entitlement external id

  * Error text: * Invalid entitlement external id

  * Http code: * 400 Bad request

* Rule: A Patient can have a maximum of twelve active PSC Entitlements
  * Error code: * EM12002

  * Error description: * Active entitlement limit

  * Error text: * The patient cannot have more than twelve active PSC Entitlements

  * Http code: * 400 Bad request

* Rule: A request to create an entitlement can be made against any valid NHI Identifier (live or dormant) for that patient.
  * Error code: * EM02002

  * Error description: * Cannot be found

  * Error text: * NHI number supplied cannot be found.

  * Http code: * 404 Not found

* Rule: A person can have multiple unique PSC entitlements (duplicates are not allowed)
  * Error code: * N/A

  * Error description: * N/A silent ignore

  * Error text: * N/A silent ignore

  * Http code: * N/A

* Rule: PSC start date must not be a future date
  * Error code: * EM07212

  * Error description: * Cannot be a future date

  * Error text: * Start date cannot be a future date

  * Http code: * 400 Bad request

* Rule: PSC Payor must be set to Te Whatu Ora (Org ID - G0K357-H)
  * Error code: * EM12029

  * Error description: * Invalid Payor

  * Error text: * Invalid Payor

  * Http code: * 400 Bad request

* Rule: Coverage period date must be a full date
  * Error code: * EM12030

  * Error description: * Coverage period date must be a full date

  * Error text: * Coverage period date must be a full date

  * Http code: * 400 Bad request


