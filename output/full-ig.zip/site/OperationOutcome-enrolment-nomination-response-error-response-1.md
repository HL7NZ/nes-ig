# enrolment-nomination-response-error-response-1 - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **enrolment-nomination-response-error-response-1**

## Example OperationOutcome: enrolment-nomination-response-error-response-1

### Issues

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Severity** | **Code** | **Diagnostics** |
| * | Error | Informational Note | Invalid correlation id |



## Resource Content

```json
{
  "resourceType" : "OperationOutcome",
  "id" : "enrolment-nomination-response-error-response-1",
  "issue" : [
    {
      "severity" : "error",
      "code" : "informational",
      "diagnostics" : "Invalid correlation id"
    }
  ]
}

```
