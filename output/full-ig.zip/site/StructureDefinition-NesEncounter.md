# NesEncounter - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NesEncounter**

## Resource Profile: NesEncounter 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org.nz/fhir/StructureDefinition/NesEncounter | *Version*:1.4.10 |
| Active as of 2025-12-09 | *Computable Name*:NesEncounter |

 
Restricts Encounter to the elemrnts need to describe an NES Enrolment qualified Encounter 

**Usages:**

* This Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.org.nz.fhir.ig.nes|current/StructureDefinition/NesEncounter)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-NesEncounter.csv), [Excel](StructureDefinition-NesEncounter.xlsx), [Schematron](StructureDefinition-NesEncounter.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "NesEncounter",
  "url" : "http://hl7.org.nz/fhir/StructureDefinition/NesEncounter",
  "version" : "1.4.10",
  "name" : "NesEncounter",
  "title" : "NesEncounter",
  "status" : "active",
  "date" : "2025-12-09T01:41:12+00:00",
  "publisher" : "Te Whatu Ora",
  "contact" : [
    {
      "name" : "Te Whatu Ora",
      "telecom" : [
        {
          "system" : "email",
          "value" : "mailto:integration@health.govt.nz"
        }
      ]
    }
  ],
  "description" : "Restricts Encounter to the elemrnts need to describe an NES Enrolment qualified Encounter",
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "workflow",
      "uri" : "http://hl7.org/fhir/workflow",
      "name" : "Workflow Pattern"
    },
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    },
    {
      "identity" : "w5",
      "uri" : "http://hl7.org/fhir/fivews",
      "name" : "FiveWs Pattern Mapping"
    },
    {
      "identity" : "v2",
      "uri" : "http://hl7.org/v2",
      "name" : "HL7 v2 Mapping"
    }
  ],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Encounter",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Encounter",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "Encounter",
        "path" : "Encounter"
      },
      {
        "id" : "Encounter.language",
        "path" : "Encounter.language",
        "max" : "0"
      },
      {
        "id" : "Encounter.statusHistory",
        "path" : "Encounter.statusHistory",
        "max" : "0"
      },
      {
        "id" : "Encounter.classHistory",
        "path" : "Encounter.classHistory",
        "max" : "0"
      },
      {
        "id" : "Encounter.type",
        "path" : "Encounter.type",
        "max" : "0"
      },
      {
        "id" : "Encounter.serviceType",
        "path" : "Encounter.serviceType",
        "max" : "0"
      },
      {
        "id" : "Encounter.priority",
        "path" : "Encounter.priority",
        "max" : "0"
      },
      {
        "id" : "Encounter.subject",
        "path" : "Encounter.subject",
        "max" : "0"
      },
      {
        "id" : "Encounter.episodeOfCare",
        "path" : "Encounter.episodeOfCare",
        "max" : "0"
      },
      {
        "id" : "Encounter.basedOn",
        "path" : "Encounter.basedOn",
        "max" : "0"
      },
      {
        "id" : "Encounter.participant",
        "path" : "Encounter.participant",
        "max" : "0"
      },
      {
        "id" : "Encounter.appointment",
        "path" : "Encounter.appointment",
        "max" : "0"
      },
      {
        "id" : "Encounter.length",
        "path" : "Encounter.length",
        "max" : "0"
      },
      {
        "id" : "Encounter.reasonCode",
        "path" : "Encounter.reasonCode",
        "max" : "0"
      },
      {
        "id" : "Encounter.reasonReference",
        "path" : "Encounter.reasonReference",
        "max" : "0"
      },
      {
        "id" : "Encounter.diagnosis",
        "path" : "Encounter.diagnosis",
        "max" : "0"
      },
      {
        "id" : "Encounter.account",
        "path" : "Encounter.account",
        "max" : "0"
      },
      {
        "id" : "Encounter.hospitalization",
        "path" : "Encounter.hospitalization",
        "max" : "0"
      },
      {
        "id" : "Encounter.location",
        "path" : "Encounter.location",
        "max" : "0"
      },
      {
        "id" : "Encounter.serviceProvider",
        "path" : "Encounter.serviceProvider",
        "max" : "0"
      },
      {
        "id" : "Encounter.partOf",
        "path" : "Encounter.partOf",
        "max" : "0"
      }
    ]
  }
}

```
