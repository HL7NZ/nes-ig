# Update Enrolment - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* **Update Enrolment**

## Update Enrolment

### Update Enrolment for Patient

The Operation is used to update an enrolment record - and is currently limited to **ending an enrolment** for:

* FLS-NF enrolment (First Level Services not funded).
* WCTO enrolment nomination (Well child Tamariki Ora services).
* LMC enrolment (Lead Maternity Carer).

**Update Enrolment processing steps:**

1. A FHIR Client sends a PUT request to the NES**EpisodeOfCare**endpoint with the enrolment id in the path, and a payload containing the NesEnrolment resource to be updated
1. The request is validated - ALT: Validation failure. Operation Outcome resource returned
1. The Enrolment EEE database is replaced in the with the enrolment resource described in the update payload
1. The updated NESEnrolment is returned to the client

#### Update Enrolment Request Example

[update to end enrolment request](updateEnrolmentRequestExample.md)

###  Update enrolment rules and errors

* Rule: An update enrolment request must contain:* An enrolment id (active)
* Contained PractitonerRole resource (Facility, Organisation and Pracitioner if present)
* Contained Patient resource
* Health service code (type)
* Enrolment status
* Enrolment-owner-org
* End Period and Termination reason code (if ending the enrolment)

  * Error code: * EM07201

  * Error description: * Is a required field

  * Error text: * Is a required field

  * Http code: * 400 Bad request

* Rule: An enrolment can only be updated by creating Organisation
  * Error code: * EM01203

  * Error description: * An enrolment can only be updated by a user representing the authorised organisation for the enrolment

  * Error text: * An enrolment can only be updated by a user representing the authorised organisation for the enrolment

  * Http code: * 400 Bad request


