# Update Entitlement - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* **Update Entitlement**

## Update Entitlement

### Update Entitlement Overview

This operation is used to update a patient's entitlement for subsidised healthcare. It is used when the entitlement reurned from the service is showing incorrect information, or if there is a need to end the entitlement.

This operation is used to update a:

* Community services card emtitlement (CSC)
* Pharmaceutical subsidy card entitlement (PSC)

#### Additional information

##### CSC

* The update CSC operation should be used when: 
* The CSC details returned from the entitlement service are different from the information on the CSC the person presents with. In the update operation the new card number will be provided. The current entitlement.id (coverage.id) will be maintained, however the entitlement will be updated to present the new details as shown on the card provided by MSD.
* A CSC entitlement needs to be ended as it has been entered in error. The card should be end dated with status 'entered-in-error'.
 

##### PSC

* The update PSC operation should be used when: 
* The PSC details returned from the entitlement service are incorrect and need updating.
* The PSC entitlement needs to be ended as it has been entered in error. The card should be end dated with status 'entered-in-error'.
 

**Update Entitlement processing steps:**

1. The user inputs details required to update or end the entitlement.
1. The integrating application sends a PUT request to the NES**Coverage**endpoint with a payload containing the NesEntitlement resource to be updated.
1. The request is validated - ALT: Validation failure. Operation Outcome resource returned
1. The Entitlement is updated in the database.
1. The updated Entitlement is returned to the client, or the Entitlement is ended.

#### Update Entitlement Request Example

[update CSC Entitlement example requests](updateCSCEntitlement.md)

[update PSC Entitlement example requests](updatePSCEntitlement.md)

### Update Entitlement Rules and Errors

#### Update community services card entitlement rules and errors

* Rule: An update CSC entitlement request must include::* A valid Entitlement ID
* Entitlement type
* beneficiary (NHI number of the patient)
* identifier (the entitlement card number)
* contained Patient resource
* organisation approving the entitlement (payor)
* status
* Period end (if ending the entitlement)

  * Error code: * EM07201

  * Error description: * Is a required field

  * Error text: * EntitlementID is a required field
* beneficiary is a required field
* identifier is a required field
* contained patient is a required field
* payor is a required field
* status is a required field

  * Http code: * 400 Bad request

* Rule: The contained patient must match Entitlement beneficiary and validate with the National Health Index
  * Error code: * EM02008

  * Error description: * The patient identity information supplied does not match the patient identity information in the NHI.

  * Error text: * The patient identity information supplied does not match the patient identity information in the NHI.

  * Http code: * 400 Bad request

* Rule: The NHI provided must match the NHI associated with the Entitlement.
  * Error code: * TBC

  * Error description: * The requested NHI is not consistent with the Entitlement.

  * Error text: * The requested NHI is not consistent with the Entitlement.

  * Http code: * 400 Bad request

* Rule: A request to update an entitlement can be made against any valid NHI Identifier (live or dormant) for that patient
  * Error code: * EM02002

  * Error description: * Cannot be found

  * Error text: * NHI number supplied cannot be found

  * Http code: * 400 Bad request

* Rule: An update CSC entitlement request must include a valid CSC Card Number.
  * Error code: * EM12006

  * Error description: * The CSC Card Number must be known to MoH

  * Error text: * The CSC Card Number must be known to MoH

  * Http code: * 400 Bad request

* Rule: A Patient can only be linked to 1 active Entitlement type i.e. CSC or CSCDependent.
  * Error code: * EM12001

  * Error description: * The patient cannot have both CSC and CSCDependent Entitlements active at the same time.

  * Error text: * The patient cannot have both CSC and CSCDependent Entitlements active at the same time.

  * Http code: * 400 Bad request

* Rule: A Patient can have a maximum of one Active CSC Entitlement.
  * Error code: * EM12002

  * Error description: * The patient cannot have more than one active CSC Entitlement.

  * Error text: * The patient cannot have more than one active CSC Entitlement.

  * Http code: * 400 Bad request

* Rule: A CSC Entitlement can only be associated to one (non-dependent) Patient.
  * Error code: * EM12003

  * Error description: * The CSC Entitlement is already assigned to another patient.

  * Error text: * The CSC Entitlement is already assigned to another patient.

  * Http code: * 400 Bad request

* Rule: A patient can have multiple CSC dependent entitlements.
  * Error code: 
  * Error description: 
  * Error text: 
  * Http code: 
* Rule: A CSC Dependent entitlement can only be created for a person 18 or younger.
  * Error code: * EM12016

  * Error description: * The patient is not a valid age to be a CSC Dependent.

  * Error text: * The patient is not a valid age to be a CSC Dependent.

  * Http code: * 400 Bad request

* Rule: An update to end entitlement must match current entitlement and include end period and status ‘entered in error’
  * Error code: * EM12026
* EM12027

  * Error description: * Invalid termination reason (status)
* Update to end must match previous entitlement

  * Error text: * Invalid termination reason (status)
* Update to end must match previous entitlement

  * Http code: * 400 Bad request


#### Update pharmaceutical subsidy cards entitlement rules and errors

* Rule: An update PSC entitlement request must include:* EntitlementID
* type of entitlement 
* beneficiary (NHI number of the patient)
* identifier (the entitlement card number)
* contained Patient resource
* organisation approving the entitlement (payor)
* status
* period - start
* period end (if ending the entitlement)

  * Error code: * EM07201
* EM12020
* EM12021

  * Error description: * Is a required field
* entitlement-id supplied cannot be found
* Supplied entitlement-id is invalid

  * Error text: * EntitlementID is a required field
* entitlement-id supplied cannot be found
* Supplied entitlement-id is invalid
* entitlement type is a required field
* contained Patient is required
* beneficiary is a required field
* identifier is a required field
* status is a required field
* payor is a required field
* period start is a required field

  * Http code: * 400 Bad request

* Rule: The entitlement must be active to be updated
  * Error code: * EM12028

  * Error description: * The requested entitlement is not active

  * Error text: * The requested entitlement is not active

  * Http code: * 400 Bad request

* Rule: The contained patient must match Entitlement beneficiary and validate with the National Health Index
  * Error code: * EM02008

  * Error description: * The patient identity information supplied does not match the patient identity information in the NHI.

  * Error text: * The patient identity information supplied does not match the patient identity information in the NHI.

  * Http code: * 400 Bad request

* Rule: The NHI provided must match the NHI associated with the Entitlement.
  * Error code: * EM12018

  * Error description: * The requested NHI is not consistent with the Entitlement.

  * Error text: * The requested NHI is not consistent with the Entitlement.

  * Http code: * 400 Bad request

* Rule: The PSC card number must be 1-16 numeric characters, with no leading zeros
  * Error code: * EM12023

  * Error description: * Invalid entitlement external id

  * Error text: * Invalid entitlement external id

  * Http code: * 400 Bad request

* Rule: Cannot update entitlement for deceased person
  * Error code: * EM12022

  * Error description: * Cannot create or update entitlement for deceased person

  * Error text: * Cannot create or update entitlement for deceased person

  * Http code: * 400 Bad request

* Rule: A request to update an entitlement can be made against any valid NHI Identifier (live or dormant) for that patient
  * Error code: * EM02002

  * Error description: * Cannot be found

  * Error text: * NHI number supplied cannot be found

  * Http code: * 400 Bad request

* Rule: A person can have multiple unique PSC entitlements (duplicates are not allowed)
  * Error code: * N/A

  * Error description: * N/A silent ignore

  * Error text: * N/A silent ignore

  * Http code: * N/A

* Rule: PSC start date must not be a future date
  * Error code: * EM07212

  * Error description: * Cannot be a future date

  * Error text: * Start date cannot be a future date

  * Http code: * 400 Bad request

* Rule: PSC end date must be greater than, or equal to start date, and not a future date
  * Error code: * EM12024
* EM12025

  * Error description: * End date cannot be before start date
* End date cannot be in the future

  * Error text: * End date cannot be before start date
* End date cannot be in the future

  * Http code: * 400 Bad request

* Rule: Coverage period date must be a full date
  * Error code: * EM12030

  * Error description: * Coverage period date must be a full date

  * Error text: * Coverage period date must be a full date

  * Http code: * 400 Bad request

* Rule: An update to end entitlement must match current entitlement and include end period and status ‘entered in error’
  * Error code: * EM12026
* EM12027

  * Error description: * Invalid termination reason (status)
* Update to end must match previous entitlement

  * Error text: * Invalid termination reason (status)
* Update to end must match previous entitlement

  * Http code: * 400 Bad request


