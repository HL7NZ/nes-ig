# Entitlement Compliance Testing - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* **Entitlement Compliance Testing**

## Entitlement Compliance Testing

### Get and Search Entitlement testing

#### NES GET Entitlement tests

* Reference: Entitlement-GET-1CSC
  * Purpose – Demonstrate that the: application displays csc entitlement information correctly:* Identifier (card number)
* Type
* NHI number
* Period

  * Input values: 20018179
  * Expected outcome: Output: CSC entitlement information is displayed for the patient
  * Mandatory: Mandatory if applicable
  * Notes: CSC Expiry: 2025-11-02
* Reference: Entitlement-GET-2CSCDEP
  * Purpose – Demonstrate that the: application displays csc-dep entitlement information correctly:* Identifier (card number)
* Type
* Relationship
* NHI number
* Period

  * Input values: 20018181
  * Expected outcome: Output:* CSC entitlement information is displayed for the patient
* Clearly shows card as CSC dependent 

  * Mandatory: Mandatory if applicable
  * Notes: CSC Dep Expiry: 2025-11-02
* Reference: Entitlement-GET-3HUHC
  * Purpose – Demonstrate that the: application displays HUHC entitlement information correctly:* Identifier (card number)
* Type
* NHI number
* Period

  * Input values: 305454455
  * Expected outcome: Output: HUHC entitlement information is displayed for the patient
  * Mandatory: Mandatory if applicable
  * Notes: HUHC Expiry: 2025-12-30
* Reference: Entitlement-GET-4PSC
  * Purpose – Demonstrate that the: application displays PSC entitlement information correctly:* Identifier (card number)
* Type
* NHI number
* Period

  * Input values: 20029300
  * Expected outcome: Output: PSC entitlement information is displayed for the patient
  * Mandatory: Mandatory if applicable
  * Notes: PSC Expiry: 2026-02-01

#### NES Search Entitlement tests

* Reference: Entitlement-Search-1CSC
  * Purpose – Demonstrate that the: application displays entitlement information correctly:* Entitlement id
* Identifier (card number)
* Type
* NHI number
* Period

  * Input values: ZKZ6088
  * Expected outcome: Output:* All entitlement information is displayed for the patient
*  Patient should have an active CSC entitlement
* Expiry: 2025-11-02

  * Mandatory: Mandatory if applicable
  * Notes: CSC Expiry: 2025-11-02
* Reference: Entitlement-Search-2PSC and CSC-Dep
  * Purpose – Demonstrate that the: application displays entitlement information correctly:* Entitlement id
* Identifier (card number)
* Type
* NHI number
* Period

  * Input values: ZKZ6096
  * Expected outcome: Output:* All entitlement information is displayed for the patient
* Patient should have an active PSC and CSC dependent entitlement

  * Mandatory: Mandatory if applicable
  * Notes: * PSC Expiry: 2026-02-01
* CSC Dep Expiry: 2025-11-02

* Reference: Entitlement-Search-3PSC and HUHC
  * Purpose – Demonstrate that the: application displays entitlement information correctly:* Entitlement id
* Identifier (card number)
* Type
* NHI number
* Period

  * Input values: ZGE7630
  * Expected outcome: Output:* All entitlement information is displayed for the patient
* Patient should have an active PSC and HUHC entitlement

  * Mandatory: Mandatory if applicable
  * Notes: * PSC Expiry: 2026-02-01
* HUHC Expiry: 2025-12-30

* Reference: Entitlement-Search-4PSC and HUHC and CSC
  * Purpose – Demonstrate that the: application displays entitlement information correctly:* Entitlement id
* Identifier (card number)
* Type
* NHI number
* Period

  * Input values: ZJV2957
  * Expected outcome: Output:* All entitlement information is displayed for the patient
* Patient should have active PSC and CSC and HUHC entitlements

  * Mandatory: Mandatory if applicable
  * Notes: * PSC Expiry: 2026-02-01
* HUHC Expiry: 2025-12-30
* HUHC Expiry: 2025-11-02

* Reference: Entitlement-Search-5PSC
  * Purpose – Demonstrate that the: application displays entitlement information correctly:* Entitlement id
* Identifier (card number)
* Type
* NHI number
* Period

  * Input values: ZLW0398
  * Expected outcome: Output:* All entitlement information is displayed for the patient
* Patient should have multiple active PSC entitlements

  * Mandatory: Mandatory if applicable
  * Notes: Both PSC Expire: 2026-02-01

### CSC Create and Update Testing

#### NES Create CSC Entitlement tests

* Reference: Entitlement-Create-CSC-1
  * Purpose – Demonstrate that the: application can create a CSC entitlement when no CSC entitlement is returned from the entitlement service, however a person presents with a CSC card
  * Input values: Use NHI (greater than 18) as provided Use a CSC card number provided
  * Expected outcome: Output: CSC entitlement is created and returned via the Entitlement service
  * Mandatory: Mandatory if applicable
* Reference: Entitlement-Create-CSC-2
  * Purpose – Demonstrate that the: application can create a CSC dependent entitlement when no CSC dependent entitlement is returned from the entitlement service, however a person presents as a dependent child of an adult with a CSC card
  * Input values: Use NHI (less than 18) as provided Use same CSC card number as Entitlement Create 1
  * Expected outcome: Output: CSC dependent entitlement is created and returned via the Entitlement service
  * Mandatory: Mandatory if applicable
* Reference: Entitlement-Create-CSC-error-1Duplicate
  * Purpose – Demonstrate that the: application can display the correct error when attempting to create a CSC entitlement that already exists
  * Input values: Use NHI (less than 18) as provided Use same CSC card number as Entitlement-Create-1
  * Expected outcome: Output: EM12002 - The patient cannot have more than one CSC Entitlement active at the same time
  * Mandatory: Mandatory if applicable
* Reference: Entitlement-Create-CSC-error-2More than one type
  * Purpose – Demonstrate that the: application can display the correct error when attempting to create:*  a CSC entitlement for a person with a CSC dependent entitlement 
*  a CSC dependent entitlement for a person with a CSC entitlement 

  * Input values: * Try to create a 'CSC dependent entitlenment' for the NHI used in Entitlement-Create-1 
* Try to create a CSC entitlementfor the NHI used in Entitlement-Create-2 

  * Expected outcome: Output: EM12001 - The patient cannot have both CSC and CSC Dependent Entitlements active at the same time
  * Mandatory: Mandatory if applicable
* Reference: Entitlement-Create-CSC-error-3Invalid NHI
  * Purpose – Demonstrate that the: application can display the correct error when attempting to create a CSC entitlement for an invalid NHI
  * Input values: Use NHI ZZZ000 and a CSC number provided
  * Expected outcome: Output: EM02002 - NHI number supplied cannot be found
  * Mandatory: Mandatory if applicable
* Reference: Entitlement-Create-CSC-error-4Invalid NHI
  * Purpose – Demonstrate that the: application can display the correct error when attempting to create a CSC entitlement with a card number that is already is use
  * Input values: Use an NHI provided, Reuse card number from Entitlement-Create-1
  * Expected outcome: Output: EM12003 - The CSC Entitlement is already assigned to another patient
  * Mandatory: Mandatory if applicable
* Reference: Entitlement-Create-CSC-error-5Card does not exist
  * Purpose – Demonstrate that the: application can display the correct error when attempting to create a CSC entitlement with a card number that does not exist
  * Input values: Use an NHI provided and, CSC number: 0123
  * Expected outcome: Output: EM12006 - The CSC Card Number must be known to MoH
  * Mandatory: Mandatory if applicable
* Reference: Entitlement-Create-CSC-error-6Card not active
  * Purpose – Demonstrate that the: application can display the correct error when attempting to create a CSC entitlement with a card number that is not active
  * Input values: Use an NHI provided and CSC number 0000000349650267
  * Expected outcome: Output: EM12011 - CSC Card number is not Active
  * Mandatory: Mandatory if applicable
* Reference: Entitlement-Create-CSC-error-7CSC dependent to old
  * Purpose – Demonstrate that the: application can display the correct error when attempting to create a CSC dep entitlement with a person who is older than 18.
  * Input values: Use an NHI provided, CSC number as provided
  * Expected outcome: Output: Output: EM12016 - The patient is not a valid age to be a CSC Dependent
  * Mandatory: Mandatory if applicable

#### NES Update CSC Entitlement tests

* Reference: Entitlement-Update-CSC-1Update CSC
  * Purpose – Demonstrate that the: application can update a CSC entitlement when the CSC entitlement returned from the entitlement service is different from that provided by a person presenting with a CSC card
  * Input values: Use NHI from Entitlement-Create-1, CSC card number as provided
  * Expected outcome: Output: CSC entitlement is created and returned via the Entitlement service
  * Mandatory: Mandatory if applicable
* Reference: Entitlement-Update-CSC-2Update CSC dependent
  * Purpose – Demonstrate that the: application can update a CSC dep entitlement when the CSC dep entitlement returned from the entitlement service is different from that provided by a person presenting with a CSC card
  * Input values: Use NHI from Entitlement-Create-2, Same CSC card number as Entitlement-Update-1
  * Expected outcome: Output: CSC dependent entitlement is created and returned via the Entitlement service
  * Mandatory: Mandatory if applicable
* Reference: Entitlement-Update-error-1Duplicate
  * Purpose – Demonstrate that the: application can display the correct error when attempting to update a CSC entitlement with details that already exist
  * Input values: Try to update a CSC entitlement with the same details in Entitlement-Update-1 and Entitlement-Update-2 (Duplicate the above to force the error).
  * Expected outcome: Output: EM12002 - The patient cannot have more than one CSC Entitlement active at the same time
  * Mandatory: Mandatory if applicable
* Reference: Entitlement-Update-error-2Card already used
  * Purpose – Demonstrate that the: application can display the correct error when attempting to update a CSC entitlement with a card number that is already in used.
  * Input values: Use new NHI number and card number from Entitlement-Update-1
  * Expected outcome: Output: EM12003 - The CSC Entitlement is already assigned to another patient
  * Mandatory: Mandatory if applicable
* Reference: Entitlement-Update-3CSC End
  * Purpose – Demonstrate that the: application can update a CSC entitlement to end it when it has been created/updated in error.
  * Input values: Use NHI from Entitlement-Update-1
  * Expected outcome: Output: CSC entitlement is ended with end reason 'entered in error'
  * Mandatory: Mandatory if applicable
* Reference: Entitlement-Update-4CSC-dep End
  * Purpose – Demonstrate that the: application can update a CSC dep entitlement to end it when it has been created/updated in error.
  * Input values: Use NHI from Entitlement-Update-2
  * Expected outcome: Output: CSC entitlement is ended with end reason 'entered in error'
  * Mandatory: Mandatory if applicable

### PSC Create and Update Testing

Note: This testing includes the NES Entitlement [Create](/createEntitlement.md) and [Update](/updateEntitlement.md) use cases and the Medication Dispense (PSC Count) API. For more information see the Search copayment count use case in the [Medical Warnings FHIR implementation guide](https://mws-ig.hip-uat.digital.health.nz/searchCoPaymentCount.html).

#### NES PSC Create, Update and PSC Count

* Scenario: Scenario-1
  * Reference: Individual – No action required
  * Purpose – Demonstrate that the: application can check the entitlements for an individual (not entitled) and, can then check the PSC count for the individual and display the count (less than 20).
  * Input values: Use NHI TBC
  * Expected outcome: Output:* No entitlements found
* Has not reached count
* No further action required

  * Mandatory: Mandatory
* Scenario: Scenario-2
  * Reference: Individual – Needs PSC card
  * Purpose – Demonstrate that the: application can check the entitlement’s for an individual (not entitled) and can then check the PSC count for the individual and display the count (20). Needs New PSC entitlement created
  * Input values: Use NHI TBC
  * Expected outcome: Output:* No entitlements found
* Has reached the correct count
* PSC entitlement created for the individual and entitlement information displayed in the PMS

  * Mandatory: Mandatory
* Scenario: Scenario-3
  * Reference: Individual - Has a PSC entitlement
  * Purpose – Demonstrate that the: application can check the entitlement for an individual and display the entitlement information
  * Input values: Use NHI TBC
  * Expected outcome: Output:* Entitlements displayed correctly

  * Mandatory: Mandatory
* Scenario: Scenario-4
  * Reference: Family unit – No action required
  * Purpose – Demonstrate that the: application can check the entitlement’s for a family unit (not entitled) and can then check the PSC count for the family unit and display the count (less than 20)
  * Input values: Use NHI TBC
  * Expected outcome: Output:* No entitlements found
* Has not reached count
* No further action required

  * Mandatory: Mandatory
* Scenario: Scenario-5
  * Reference: Family unit – Check family unit member entitlement (not entitled), check family unit count (eligible) create and extent entitlement to family unit member/s
  * Purpose – Demonstrate that the: application can check the entitlement’s for a family unit (not entitled), can then check the PSC count for the family unit and display the count (20), and the create a new PSC entitlement for all members of the family unit
  * Input values: Use NHI TBC
  * Expected outcome: Output:* No entitlements
* Has reached count
* PSC entitlement created for each member of the family with the same PSC card number, and entitlement information displayed.

  * Mandatory: Mandatory
* Scenario: Scenario-6
  * Reference: Individual – End entitlement
  * Purpose – Demonstrate that the: application can end an entitlement for an individual where it has been entered in error
  * Input values: Use NHI TBC
  * Expected outcome: Output:* Entitlement removed and not returned from the entitlement service

  * Mandatory: Mandatory
* Scenario: Scenario-7
  * Reference: Family Unit – End entitlement
  * Purpose – Demonstrate that the: application can end an entitlement for a family unit where it has been entered in error
  * Input values: Use NHI TBC
  * Expected outcome: Output:* Entitlements for family unit removed and not returned from the entitlement service

  * Mandatory: Mandatory
* Scenario: Scenario-8
  * Reference: Individual - Exceeds 12 concurrent entitlements
  * Purpose – Demonstrate that the: application can assign up to 12 PSC entitlements to a family unit member, where that person is part of multiple family units
  * Input values: Use NHI TBC
  * Expected outcome: Output:* Individual has multiple PSC entitlements associated with their NHI

  * Mandatory: Mandatory
* Scenario: Scenario-9
  * Reference: Individual - Exceeds 12 concurrent entitlements
  * Purpose – Demonstrate that the: application can display the correct error when attempting to add a PSC entitlement for a family unit member that has 12 entitlements
  * Input values: Use NHI TBC
  * Expected outcome: Output:* Error returned: EM12002 - The patient cannot have more than twelve active PSC Entitlements

  * Mandatory: Mandatory
* Scenario: Scenario-10
  * Reference: Family Unit - Search exceeds maximum number of NHIs
  * Purpose – Demonstrate that the: application can display the correct error when attempting to return a count for a family unit with greater that 20 members
  * Input values: Use NHI TBC
  * Expected outcome: Output:* Error returned: EM7243 - Max of 20 NHIs may be provided

  * Mandatory: Mandatory
* Scenario: Scenario-11
  * Reference: Individual - Create entitlement for deceased person
  * Purpose – Demonstrate that the: application can display the correct error when attempting to create a a PSC entitlement for a deceased person
  * Input values: Use NHI TBC
  * Expected outcome: Output:* Error returned: EM12022 - Cannot create or update entitlement for deceased person

  * Mandatory: Mandatory
* Scenario: Scenario-12
  * Reference: Individual - Update entitlement for deceased person
  * Purpose – Demonstrate that the: application can display the correct error when attempting to create a a PSC entitlement for a deceased person
  * Input values: Use NHI TBC
  * Expected outcome: Output:* Error returned: EM12022 - Cannot create or update entitlement for deceased person

  * Mandatory: Mandatory
* Scenario: Scenario-13
  * Reference: Individual - Create entitlement for a future start date
  * Purpose – Demonstrate that the: application can display the correct error when attempting to create a PSC entitlement for a future date (period start)
  * Input values: Use NHI TBC
  * Expected outcome: Output:* Error returned: EM07212 - Start date cannot be a future date

  * Mandatory: Mandatory
* Scenario: Scenario-14
  * Reference: Individual - Update entitlement for a future start date
  * Purpose – Demonstrate that the: application can display the correct error when attempting to update a PSC entitlement for a future date (period start)
  * Input values: Use NHI TBC
  * Expected outcome: Output:* Error returned: EM07212 - Start date cannot be a future date

  * Mandatory: Mandatory
* Scenario: Scenario-15
  * Reference: Family Unit - Extend (create) expired PSC entitlement to additional family unit members
  * Purpose – Demonstrate that the: application can display the correct error when attempting to extend a PSC entitlement to family unit members with an expired entitlement number
  * Input values: Use NHI TBC
  * Expected outcome: Output:* Error returned: EM12006 - The PSC Card Number must be known to Te Whatu Ora

  * Mandatory: Mandatory
* Scenario: Scenario-16
  * Reference: Family Unit - Extend (create) PSC entitlement to additional family unit members
  * Purpose – Demonstrate that the: application can display the correct error when attempting to extend a PSC entitlement to family unit members with an unassigned entitlement number
  * Input values: Use NHI TBC
  * Expected outcome: Output:* Error returned: EM12006 - The PSC Card Number must be known to Te Whatu Ora

  * Mandatory: Mandatory
* Scenario: Scenario-17
  * Reference: Individual - Update expired PSC entitlement
  * Purpose – Demonstrate that the: application can display the correct error when attempting to update an expired PSC entitlement
  * Input values: Use NHI TBC
  * Expected outcome: Output:* Error Returned: EM12028 - The requested entitlement is not active

  * Mandatory: Mandatory
* Scenario: Scenario-18
  * Reference: Individual - Update entitlement number for an NHI
  * Purpose – Demonstrate that the: application can update and replace valid entitlement number registered to an NHI (assumes that the updated entitlement number is valid and active)
  * Input values: Use NHI TBC
  * Expected outcome: Output:* Entitlement record is changed with updated entitlement card number

  * Mandatory: Mandatory
* Scenario: Scenario-19
  * Reference: Individual - Update invalid entitlement for an NHI
  * Purpose – Demonstrate that the: application can display the correct error when attempting to update an entitlement number for an NHI with a value that is invalid (does not exist)
  * Input values: Use NHI TBC
  * Expected outcome: Output:* Error Returned: EM12020 - entitlement-id supplied cannot be found

  * Mandatory: Mandatory
* Scenario: Scenario-20
  * Reference: Individual - create entitlement, invalid NHI
  * Purpose – Demonstrate that the: application can display the correct error when attempting to create an entitlement number for an invalid NHI (does not exist)
  * Input values: Use NHI TBC
  * Expected outcome: Output:* Error returned: EM02002 - NHI number supplied cannot be found

  * Mandatory: Mandatory
* Scenario: Scenario-21
  * Reference: Individual - Create entitlement with invalid patient details
  * Purpose – Demonstrate that the: application can display the correct error when attempting to create an entitlement number for a valid NHI but with mismatched patient information e.g. DoB
  * Input values: Use NHI TBC
  * Expected outcome: Output:* EM02008 -The patient identity information supplied does not match the patient identity information in the NHI.

  * Mandatory: Mandatory
* Scenario: Scenario-22
  * Reference: Individual - Update entitlement with invalid patient details
  * Purpose – Demonstrate that the: application can display the correct error when attempting to update an entitlement number for a valid NHI but with mismatched patient information e.g. DoB
  * Input values: Use NHI TBC
  * Expected outcome: Output:* EM02008 -The patient identity information supplied does not match the patient identity information in the NHI.

  * Mandatory: Mandatory
* Scenario: Scenario-23
  * Reference: Blended Family - One family eligible
  * Purpose – Demonstrate that the: application can correctly handle the scenario where a dependent belongs to two family units and only one of these family units is entitled to the PSC entitlement.
  * Input values: **Family Unit A*** Caregiver #1: 3
* Caregiver #2: 4
* 5yo dependent: 0 - will always be zero due to age
* 15yo dependent: 2
* 17yo dependent (also part of Family Unit B): 4
* **Family Unit A total: 13**
**Family Unit B:*** Caregiver #1: 4
* Caregiver #2: 16
* 17yo dependent: 4, as above
* 19yo dependent: any count - excluded from total due to age
* **Family Unit B total: 24**
Output:1. Verify Co-Payment Count Inclusion:
1. Check Family Unit B PSC Entitlement:
1. Validate Entitlement Segregation:
Mandatory</tr>Scenario-24Blended Family - Both family eligible (A)application can correctly handle the scenario where a dependent belongs to two family units and both of these family units are entitled to the PSC entitlement. This scenario follows on from Scenario 23 (Blended Family - One family eligible). Family Unit A have now become eligible for a PSC entitlement.**Family Unit A*** Caregiver #1: 4
* Caregiver #2: 8
* 5yo dependent: 0 - will always be zero due to age
* 15yo dependent: 4
* 17yo dependent (also part of Family Unit B): 4
* **Family Unit A total: 20**
**Family Unit B:*** Caregiver #1: 4
* Caregiver #2: 16
* 17yo dependent: 4, as above
* 19yo dependent: any count - excluded from total due to age
* **Family Unit B total: 24**
Output:1. Verify Co-Payment Count Inclusion:
1. Check Family Unit A & B PSC Entitlement:
1. Validate Entitlement Segregation:
Mandatory</tr>Scenario-25Blended Family - Both family eligible (B)application can correctly handle the scenario where a dependent belongs to two family units and both of these family units are entitled to the PSC entitlement. In this scenario, the 17-year-old dependent has met the count of 20 by themselves​, and all other family members of Family Units A and B have counts of Zero.**Family Unit A*** Caregiver #1: 0
* Caregiver #2: 0
* 5yo dependent: 0 - will always be zero due to age
* 15yo dependent: 0
* 17yo dependent (also part of Family Unit B): 20
* **Family Unit A total: 20**
**Family Unit B:*** Caregiver #1: 0
* Caregiver #2: 0
* 17yo dependent: 20, as above
* 19yo dependent: any count - excluded from total due to age
* **Family Unit B total: 20**
Output:1. Verify Co-Payment Count Inclusion:
1. Check Family Unit A & B PSC Entitlement:
1. Validate Entitlement Segregation:
Mandatory</tr> </table>

