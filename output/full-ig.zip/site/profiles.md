# Profiles - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* **Profiles**

## Profiles

**Profiles defined in this guide**

* Id: [EnrolmentNominationResponse](StructureDefinition-EnrolmentNominationResponse.md)
  * Url: http://hl7.org.nz/fhir/StructureDefinition/EnrolmentNominationResponse
  * Description: Adds additional, NES specific extensions
* Id: [NesEncounter](StructureDefinition-NesEncounter.md)
  * Url: http://hl7.org.nz/fhir/StructureDefinition/NesEncounter
  * Description: Restricts Encounter to the elemrnts need to describe an NES Enrolment qualified Encounter
* Id: [NesEnrolment](StructureDefinition-NesEnrolment.md)
  * Url: http://hl7.org.nz/fhir/StructureDefinition/NesEnrolment
  * Description: Adds additional, NES specific extensions for enrolments
* Id: [NesEntitlement](StructureDefinition-NesEntitlement.md)
  * Url: http://hl7.org.nz/fhir/StructureDefinition/NesEntitlement
  * Description: The coverage resource contains information related to Patient entitlements
* Id: [NesPatient](StructureDefinition-NesPatient.md)
  * Url: http://hl7.org.nz/fhir/StructureDefinition/NesPatient
  * Description: A minimal profile of NzPatient, containing just enough information to validate a patient's NHI for the purposes of enrolment
* Id: [NesPractitionerRole](StructureDefinition-NesPractitionerRole.md)
  * Url: http://hl7.org.nz/fhir/StructureDefinition/NesPractitionerRole
  * Description: A minimal profile of PractitionerRole, which just contains references to the enrolling facility, organisation and practitioner

