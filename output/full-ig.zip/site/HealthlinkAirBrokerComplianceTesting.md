# Healthlink Air Broker Compliance Testing - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* **Healthlink Air Broker Compliance Testing**

## Healthlink Air Broker Compliance Testing

### Healthlink Air Broker Compliance Testing

#### Healthlink Air Broker Compliance Testing

* Reference: EN-HealthLink-1-AA
  * Purpose – Demonstrate that the: application can send an ADT^28 ACK response – Accept Enrolment Nomination ‘AA’
  * Input values: TBC
  * Expected outcome: Accept Enrolment Nomination sent to NBES in agreed format
  * Mandatory: Mandatory
* Reference: EN-HealthLink-2-AR
  * Purpose – Demonstrate that the: application can send an ADT^28 ACK response – Rejection Enrolment Nomination ‘AR’
  * Input values: TBC
  * Expected outcome: Reject Enrolment Nomination sent to NBES in agreed format
  * Mandatory: Mandatory
* Reference: EN-HealthLink-3-Error
  * Purpose – Demonstrate that the: application can send an error response for an invalid Enrolment nomination
  * Input values: TBC
  * Expected outcome: Error response for an invalid Enrolment nomination returned to NBES.
  * Mandatory: Mandatory

