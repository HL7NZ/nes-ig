# do-not-populate-id - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **do-not-populate-id**

## Example EpisodeOfCare: do-not-populate-id



## Resource Content

```json
{
  "resourceType" : "EpisodeOfCare",
  "id" : "do-not-populate-id",
  "contained" : [
    {
      "resourceType" : "PractitionerRole",
      "id" : "EnrolmentServiceProvider5",
      "practitioner" : {
        "reference" : "Practitioner/99ZZZS",
        "display" : "Mrs TestOne Prefix-Test"
      },
      "organization" : {
        "reference" : "Organization/GZZ998-G",
        "display" : "Live Org with Dormant"
      },
      "location" : [
        {
          "reference" : "Location/FZZ968-B",
          "display" : "Facility Has All Contact Types TEST"
        }
      ]
    },
    {
      "resourceType" : "Patient",
      "id" : "ZJJ8114",
      "meta" : {
        "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/NesPatient"]
      },
      "name" : [
        {
          "family" : "Mathieu",
          "given" : ["Francesca"]
        }
      ],
      "birthDate" : "2000-03-03"
    }
  ],
  "extension" : [
    {
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/enrolment-expiry-date",
      "valueDate" : "2026-06-05"
    },
    {
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/enrolment-owner-org",
      "valueReference" : {
        "reference" : "Organization/GZZ998-G",
        "display" : "Live Org with Dormant"
      }
    }
  ],
  "status" : "active",
  "type" : [
    {
      "coding" : [
        {
          "system" : "https://standards.digital.health.nz/nes-enrolment-type",
          "code" : "FLS"
        }
      ]
    }
  ],
  "patient" : {
    "reference" : "#ZJJ8114"
  },
  "careManager" : {
    "reference" : "#EnrolmentServiceProvider5"
  }
}

```
