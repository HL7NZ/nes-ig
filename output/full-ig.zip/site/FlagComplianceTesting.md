# Flag Compliance Testing - New Zealand NES IG v1.5.0

* [**Table of Contents**](toc.md)
* **Flag Compliance Testing**

## Flag Compliance Testing

### SearchFlag testing

#### Search Flags tests

* Reference: Flag-Search 1 – NCCI flagCSC
  * Purpose – Demonstrate that the: application can display a flag and make it apparent to the end user.
  * Input values: NHI
  * Expected outcome: Output:NCCI Flag displayed on screen in an area apparent to the user of the system
  * Mandatory: Mandatory
  * Notes: 
* Reference: Flag-Search 2 – NCCI detailsCSC
  * Purpose – Demonstrate that the: Application can make the information from the link easily available to the end user.
  * Input values: NHI
  * Expected outcome: Output: Link information is made easily available to the end user (E.g. User can click on the website url and the information is made available, or the application cache the information, makes it available and refreshes every 24 hours.
  * Mandatory: Mandatory
  * Notes: 
* Reference: Flag-Search 3 – NCCI periodCSC
  * Purpose – Demonstrate that the: Application can make all other flag information available to the end user.* Period start
* Period end

  * Input values: NHI
  * Expected outcome: Output: Link information is made easily available to the end user (E.g. User can click on the website url and the information is made available, or the application cache the information, makes it available and refreshes every 24 hours.
  * Mandatory: Mandatory
  * Notes: 
* Reference: Flag-Search 4 – no flagCSC
  * Purpose – Demonstrate that the: Application can gracefully handle scenarios where a patient has no flags
  * Input values: NHI
  * Expected outcome: Output: No Flag information returned.
  * Mandatory: Mandatory
  * Notes: 
* Reference: Flag-Search 5 – Error1CSC
  * Purpose – Demonstrate that the: Application can alert the user that the Flag service cannot be reached.
  * Input values: NHI
  * Expected outcome: Output: An error message is returned that clearly articulates that the service is unavailable.
  * Mandatory: Mandatory
  * Notes: 
* Reference: Flag-Search 6 – Error2CSC
  * Purpose – Demonstrate that the: Application can alert the user that the NHI was not found..
  * Input values: NHI
  * Expected outcome: Output: An error message is returned that clearly articulates that the NHI is invalid or is not found in the NHI. (EM02002 - Cannot be found)
  * Mandatory: Mandatory
  * Notes: 
* Reference: Flag Search-2 multiple flagsCSC
  * Purpose – Demonstrate that the: application can display all flags returned by the service and make them apparent to the end user.
  * Input values: NHI
  * Expected outcome: Output: Multiple Flags are displayed on screen in an area apparent to the user of the system.
  * Mandatory: Mandatory – Future scope Show us how the system is being designed to be extensible.
  * Notes: 

