# enrolment-1 - New Zealand NES IG v1.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **enrolment-1**

## Example EpisodeOfCare: enrolment-1



## Resource Content

```json
{
  "resourceType" : "EpisodeOfCare",
  "id" : "EN667788899",
  "contained" : [{
    "resourceType" : "PractitionerRole",
    "id" : "EnrolmentServiceProvider1",
    "practitioner" : {
      "reference" : "Practitioner/99ZZZS",
      "display" : "Mrs TestOne Prefix-Test"
    },
    "organization" : {
      "reference" : "Organization/GZZ998-G",
      "display" : "Live Org with Dormant"
    },
    "location" : [{
      "reference" : "Location/FZZ968-B",
      "display" : "Facility Has All Contact Types TEST"
    }]
  },
  {
    "resourceType" : "Patient",
    "id" : "ZJM9397",
    "meta" : {
      "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/NesPatient"]
    },
    "name" : [{
      "family" : "Ryan",
      "given" : ["Jamie", "Joseph"]
    }],
    "birthDate" : "1972-06-05"
  }],
  "extension" : [{
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/enrolment-expiry-date",
    "valueDate" : "2026-06-05"
  },
  {
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/reenrolment-date",
    "valueDate" : "2022-06-05"
  },
  {
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/enrolment-owner-org",
    "valueReference" : {
      "reference" : "Organization/GZZ998-G",
      "display" : "Live Org with Dormant"
    }
  },
  {
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/nes-enrolment-termination-reason",
    "valueCodeableConcept" : {
      "coding" : [{
        "system" : "https://standards.digital.health.nz/nes-enrolment-termination-reason",
        "code" : "Transfer"
      }]
    }
  },
  {
    "url" : "http://hl7.org.nz/fhir/StructureDefinition/enrolment-encounter",
    "valueReference" : {
      "reference" : "QualifiedEncounter1"
    }
  }],
  "identifier" : [{
    "system" : "https://standards.digital.health.nz/ns/nes-enrolment-id",
    "value" : "EN667788899"
  }],
  "status" : "active",
  "type" : [{
    "coding" : [{
      "system" : "https://standards.digital.health.nz/nes-enrolment-type",
      "code" : "FLS-NF"
    }]
  }],
  "patient" : {
    "reference" : "#ZJM9397"
  },
  "careManager" : {
    "reference" : "#EnrolmentServiceProvider1"
  }
}

```
