# NES PractitionerRole - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NES PractitionerRole**

## Resource Profile: NES PractitionerRole 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org.nz/fhir/StructureDefinition/NesPractitionerRole | *Version*:1.4.10 |
| Active as of 2025-12-09 | *Computable Name*:NesPractitionerRole |

 
A minimal profile of PractitionerRole, which just contains references to the enrolling facility, organisation and practitioner 

**Usages:**

* Use this Profile: [NES Enrolment](StructureDefinition-NesEnrolment.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.org.nz.fhir.ig.nes|current/StructureDefinition/NesPractitionerRole)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-NesPractitionerRole.csv), [Excel](StructureDefinition-NesPractitionerRole.xlsx), [Schematron](StructureDefinition-NesPractitionerRole.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "NesPractitionerRole",
  "url" : "http://hl7.org.nz/fhir/StructureDefinition/NesPractitionerRole",
  "version" : "1.4.10",
  "name" : "NesPractitionerRole",
  "title" : "NES PractitionerRole",
  "status" : "active",
  "date" : "2025-12-09T01:41:12+00:00",
  "publisher" : "Te Whatu Ora",
  "contact" : [
    {
      "name" : "Te Whatu Ora",
      "telecom" : [
        {
          "system" : "email",
          "value" : "mailto:integration@health.govt.nz"
        }
      ]
    }
  ],
  "description" : "A minimal profile of PractitionerRole, which just contains references to the enrolling facility, organisation and practitioner",
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "v2",
      "uri" : "http://hl7.org/v2",
      "name" : "HL7 v2 Mapping"
    },
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    },
    {
      "identity" : "servd",
      "uri" : "http://www.omg.org/spec/ServD/1.0/",
      "name" : "ServD"
    },
    {
      "identity" : "w5",
      "uri" : "http://hl7.org/fhir/fivews",
      "name" : "FiveWs Pattern Mapping"
    }
  ],
  "kind" : "resource",
  "abstract" : false,
  "type" : "PractitionerRole",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/PractitionerRole",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "PractitionerRole.language",
        "path" : "PractitionerRole.language",
        "max" : "0"
      },
      {
        "id" : "PractitionerRole.contained",
        "path" : "PractitionerRole.contained",
        "max" : "0"
      },
      {
        "id" : "PractitionerRole.extension",
        "path" : "PractitionerRole.extension",
        "max" : "0"
      },
      {
        "id" : "PractitionerRole.identifier",
        "path" : "PractitionerRole.identifier",
        "max" : "0"
      },
      {
        "id" : "PractitionerRole.active",
        "path" : "PractitionerRole.active",
        "max" : "0"
      },
      {
        "id" : "PractitionerRole.period",
        "path" : "PractitionerRole.period",
        "max" : "0"
      },
      {
        "id" : "PractitionerRole.code",
        "path" : "PractitionerRole.code",
        "max" : "0"
      },
      {
        "id" : "PractitionerRole.healthcareService",
        "path" : "PractitionerRole.healthcareService",
        "max" : "0"
      },
      {
        "id" : "PractitionerRole.telecom",
        "path" : "PractitionerRole.telecom",
        "max" : "0"
      },
      {
        "id" : "PractitionerRole.availableTime",
        "path" : "PractitionerRole.availableTime",
        "max" : "0"
      },
      {
        "id" : "PractitionerRole.notAvailable",
        "path" : "PractitionerRole.notAvailable",
        "max" : "0"
      }
    ]
  }
}

```
