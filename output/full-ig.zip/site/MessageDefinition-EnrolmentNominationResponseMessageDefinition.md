# EnrolmentNominationResponseMessageDefinition - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EnrolmentNominationResponseMessageDefinition**

## MessageDefinition: EnrolmentNominationResponseMessageDefinition 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org.nz/fhir/MessageDefinition/EnrolmentNominationResponseMessageDefinition | *Version*:1.4.10 |
| Draft as of 2020-04-21 | *Computable Name*: |

 
Defines the message used to respond to a request for an enrolment 

**url**: [MessageDefinition: url = http://hl7.org.nz/fhir/MessageDefinition/EnrolmentNominationResponseMessageDefinition; version = 1.4.10; status = draft; date = 2020-04-21; publisher = Te Whatu Ora; contact = Te Whatu Ora (mailto:integration@health.govt.nz); description = Defines the message used to respond to a request for an enrolment; jurisdiction = ; copyright = ; event[x] = GP Enrolment Nomination Acknowledgement (NES Event Type#FLS_ENROLMENT_NOMINATION_ACK)](MessageDefinition-EnrolmentNominationResponseMessageDefinition.md)

**version**: 1.4.10

**status**: Draft

**date**: 2020-04-21

**publisher**: Te Whatu Ora

**contact**: Te Whatu Ora: [mailto:integration@health.govt.nz](mailto:mailto:integration@health.govt.nz)

**description**: 

Defines the message used to respond to a request for an enrolment

**event**: [NES Event Type: FLS_ENROLMENT_NOMINATION_ACK](https://common-ig.hip.digital.health.nz/site/CodeSystem-nes-event-type-1.0.html#nes-event-type-1.0-FLS_ENROLMENT_NOMINATION_ACK) (GP Enrolment Nomination Acknowledgement)

### Focus

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| - | **Code** | **Profile** | **Min** | **Max** |
| * | OperationOutcome | [EnrolmentNominationResponse](StructureDefinition-EnrolmentNominationResponse.md) | 1 | 1 |



## Resource Content

```json
{
  "resourceType" : "MessageDefinition",
  "id" : "EnrolmentNominationResponseMessageDefinition",
  "url" : "http://hl7.org.nz/fhir/MessageDefinition/EnrolmentNominationResponseMessageDefinition",
  "version" : "1.4.10",
  "status" : "draft",
  "date" : "2020-04-21",
  "publisher" : "Te Whatu Ora",
  "contact" : [
    {
      "name" : "Te Whatu Ora",
      "telecom" : [
        {
          "system" : "email",
          "value" : "mailto:integration@health.govt.nz"
        }
      ]
    }
  ],
  "description" : "Defines the message used to respond to a request for an enrolment",
  "eventCoding" : {
    "system" : "https://standards.digital.health.nz/ns/nes-event-type",
    "code" : "FLS_ENROLMENT_NOMINATION_ACK"
  },
  "focus" : [
    {
      "code" : "OperationOutcome",
      "profile" : "http://hl7.org.nz/fhir/StructureDefinition/EnrolmentNominationResponse",
      "min" : 1,
      "max" : "1"
    }
  ]
}

```
