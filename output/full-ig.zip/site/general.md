# General - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* **General**

## General

The following notes apply to all resources in this implementation.

### Resource representation: Json

Only Json is supported by this implementation.

### Errors

#### HTTP Error response codes

* Status code: 400
  * Description: Bad Request
* Status code: 401
  * Description: The client needs to provide credentials, or has provided invalid credentials.
* Status code: 403
  * Description: Authentication was provided, but the authenticated user is not permitted to perform the requested operation.
* Status code: 404
  * Description: Resource not found
* Status code: 405
  * Description: HTTP method not allowed
* Status code: 409
  * Description: Resource conflict, the version provided for the resource is not the current version
* Status code: 413
  * Description: The request body was too big for the server to accept
* Status code: 422
  * Description: Unprocessable Entity, resource was rejected by the server because it “violated applicable FHIR profiles or server business rules”
* Status code: 500
  * Description: General system failure
* Status code: 429
  * Description: Exceeded quota

#### Response Body

The Response body may contain an OperationOutcome resource describing the result of the request message processing 
 The table below describes how the OperationOutcome should be populated 

* Field: OperationOutcome.issue
  * Description: 
  * Cardinality: 0..n
* Field: OperationOutcome.issue[].severity
  * Description: error
  * Cardinality: 0..1
* Field: OperationOutcome.issue[].code
  * Description: processing
  * Cardinality: 0..1
* Field: OperationOutcome.issue[].details.coding.system
  * Description: https://standards.digital.health.nz/ns/hip-error-code
  * Cardinality: 0..1
* Field: OperationOutcome.issue[].details.coding.code
  * Description: [See the HIP Error codes](https://dev.d3ox9vcqia2rpj.amplifyapp.com/site/CodeSystem-hip-error-code.html)
  * Cardinality: 0..1
* Field: OperationOutcome.issue[].details.coding.display
  * Description: [See the HIP Error codes](https://dev.d3ox9vcqia2rpj.amplifyapp.com/site/CodeSystem-hip-error-code.html)
  * Cardinality: 0..1
* Field: OperationOutcome.issue[].details.text
  * Description: See indicative text on each operation use case
  * Cardinality: 0..1

#### Error Format

```

{
    "resourceType": "OperationOutcome",
    "issue": [
        {
            "severity": "error",
            "code": "processing",
            "details": {
                "coding": [
                    {
                        "system": "https://standards.digital.health.nz/ns/hip-error-code",
                        "code": "EM07201"
                        "display": "Missing a required field"
                    }
                ],
                "text": "Name is a required field"
            }
        }
    ]
}


```

### Request Rules and Errors

* **Request rules** 
* Every request must include an: 
* http header item UserId that uniquely identifies the individual initiating the request.
* OAuth 2 access token
* An api-key
 
 
* **Request errors** 
* **Authentication: missing userid header**, **HTTP401, Processing**
* **Unauthorized**, **HTTP401**
* **Forbidden, HTTP403**
 

### HTTP Header Details

* This is a list of any additions to standard HTTP header protocol

### Request Headers

* HTTP Header (Key): Authorization
  * HTTP Header (Value): Bearer {string}
  * Description: The OAuth2 access token
  * Mandatory / Recommended / Optional: Mandatory
* HTTP Header (Key): userid
  * HTTP Header (Value): {string}
  * Description: Client providedAll requests for all resources must include an http header userid that uniquely identifies the individual initiating the requestPreferably the hpi-person-id of the user would be provided if known, otherwise a userid that allows the authenticated organisation to identify the individual
  * Mandatory / Recommended / Optional: Mandatory
* HTTP Header (Key): X-Correlation-Id
  * HTTP Header (Value): {string}
  * Description: Client providedAll requests should contain a unique transaction id in the X-Correlation-Id fieldIf present in the request this will be returned in the response, and can be used to track API callsPreferred less than 64 characters
  * Mandatory / Recommended / Optional: Recommended
* HTTP Header (Key): Content-Type
  * HTTP Header (Value): Application/json
  * Description: Supported content type
  * Mandatory / Recommended / Optional: Mandatory
* HTTP Header (Key): x-api-key
  * HTTP Header (Value): {string}
  * Description: Te Whatu Ora Provided – issued with client credentials
  * Mandatory / Recommended / Optional: Mandatory

### Response Headers

* Element name: X-Correlation-Id
  * Value: {string}
  * Description: Returned if provided
* Element name: X-request-Id
  * Value: {string}
  * Description: Unique identifier for the request within the NHI
* Element name: ETag
  * Value: {string}
  * Description: The resource version number, returned on a Get

### Security

#### OAUTH2

The NES server uses the OAUTH2 Client Credentials flow for authentication and authorisation and complies with the SMART specification for backend services

#### Scopes

The following scopes are supported. For more information on available functionality please see [Business Functions](/Onboarding.md#business-functions).

* Domain: Enrolment
  * SMART on FHIR Scopes: https://api.hip.digital.health.nz/fhir/system/EpisodeOfCare.r
  * Description: Read access to Enrolment records
* Domain: Enrolment
  * SMART on FHIR Scopes: https://api.hip.digital.health.nz/fhir/system/EpisodeOfCare.s
  * Description: Search access to Enrolment records
* Domain: Enrolment
  * SMART on FHIR Scopes: https://api.hip.digital.health.nz/fhir/system/EpisodeOfCare.u
  * Description: Update access to Enrolment records
* Domain: Enrolment
  * SMART on FHIR Scopes: https://api.hip.digital.health.nz/fhir/system/EpisodeOfCare.c
  * Description: Create access to Enrolment records
* Domain: Entitlement
  * SMART on FHIR Scopes: https://api.hip.digital.health.nz/fhir/system/Coverage.r
  * Description: Read access to Entitlement records
* Domain: Entitlement
  * SMART on FHIR Scopes: https://api.hip.digital.health.nz/fhir/system/Coverage.s
  * Description: Search access to Entitlement records
* Domain: Entitlement
  * SMART on FHIR Scopes: https://api.hip.digital.health.nz/fhir/system/Coverage.u
  * Description: Update access to Entitlement records
* Domain: Entitlement
  * SMART on FHIR Scopes: https://api.hip.digital.health.nz/fhir/system/Coverage.c
  * Description: Create access to Entitlement records
* Domain: New born enrolments
  * SMART on FHIR Scopes: https://api.hip.digital.health.nz/fhir/system/MessageHeader.c
  * Description: Create and respond to enrolment nomination

#### API Keys and Usage Plans

Clients will be emailed their API key, which should be treated as confidential information and not shared with other parties

An api-key associates the client with a usage plan, which sets upper limits on the API request volume which is permitted. If a client exceeds their usage plan allocation an http error will be returned

Clients will need to add their api key to the x-api-key header in each API request. If no API key is included in the request header, a “Forbidden” error will be returned

### Usage Plans

* Plan: bronze
  * Rate: 1 request per second
  * Burst: 5
  * Quota: 10,000 requests per day
* Plan: silver
  * Rate: 5 requests per second
  * Burst: 25
  * Quota: 250,000 requests per day
* Plan: gold
  * Rate: 10 requests per second
  * Burst: 50
  * Quota: 500,000 requests per day

All test accounts will be assigned to the bronze usage plan. If a Vendor wishes to be assigned to a higher plan, they should contact the Integration team via the [General Enquiry form](https://mohapis.atlassian.net/servicedesk/customer/portal/3/group/35/create/112). Please request a change to the usage plan and make sure you include the ClientID at minimum (AppId and Orgid also recommended).

Production accounts will be assigned to the silver usage plan. If an Organisation wishes to be assigned to the gold usage plan, they should contact the Te Whatu Ora [NHI access team](mailto:NHI_Access@health.govt.nz)

If an application reaches its usage plan limit an HTTP 429 error will be returned. The expected behaviour is that the application will retry several times with an exponentially increasing delay

#### GEO Restriction

GEO Restriction rules prevent access from clients with IPs located in countries other than those listed below. If you need access from another country, please contact our team by completing the [Enquiry form](https://mohapis.atlassian.net/servicedesk/customer/portal/3/group/35/create/112). or adding a comment to the online onboarding request form if you have one.

* New Zealand
* Australia
* Canada
* Cook Islands

