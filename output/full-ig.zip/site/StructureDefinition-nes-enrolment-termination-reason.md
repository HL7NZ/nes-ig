# Nes_enrolment_termination_reason - New Zealand NES IG v1.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Nes_enrolment_termination_reason**

## Extension: Nes_enrolment_termination_reason 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org.nz/fhir/StructureDefinition/nes-enrolment-termination-reason | *Version*:1.5.0 |
| Draft as of 2026-04-22 | *Computable Name*:Nes_enrolment_termination_reason |

NES Enrolment Termination Reason Code

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [NES Enrolment](StructureDefinition-NesEnrolment.md)
* Examples for this Extension: [EpisodeOfCare/EN12349876](EpisodeOfCare-EN12349876.md) and [EpisodeOfCare/EN667788899](EpisodeOfCare-EN667788899.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.org.nz.fhir.ig.nes|current/StructureDefinition/nes-enrolment-termination-reason)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-nes-enrolment-termination-reason.csv), [Excel](StructureDefinition-nes-enrolment-termination-reason.xlsx), [Schematron](StructureDefinition-nes-enrolment-termination-reason.sch) 

#### Terminology Bindings

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "nes-enrolment-termination-reason",
  "url" : "http://hl7.org.nz/fhir/StructureDefinition/nes-enrolment-termination-reason",
  "version" : "1.5.0",
  "name" : "Nes_enrolment_termination_reason",
  "status" : "draft",
  "date" : "2026-04-22T02:08:05+00:00",
  "publisher" : "Te Whatu Ora",
  "contact" : [{
    "name" : "Te Whatu Ora",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:integration@health.govt.nz"
    }]
  }],
  "description" : "NES Enrolment Termination Reason Code",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "EpisodeOfCare"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "definition" : "NES Enrolment Termination Reason Code"
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "http://hl7.org.nz/fhir/StructureDefinition/nes-enrolment-termination-reason"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "type" : [{
        "code" : "CodeableConcept"
      }],
      "binding" : {
        "strength" : "preferred",
        "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/nes-enrolment-termination-reason"
      }
    }]
  }
}

```
