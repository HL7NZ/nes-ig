# NES Entitlements - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NES Entitlements**

## Resource Profile: NES Entitlements 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org.nz/fhir/StructureDefinition/NesEntitlement | *Version*:1.4.10 |
| Active as of 2025-12-09 | *Computable Name*:NesEntitlement |

 
The coverage resource contains information related to Patient entitlements 

**Usages:**

* Examples for this Profile: [Coverage/EN5544332211](Coverage-EN5544332211.md), [Coverage/EN667788899](Coverage-EN667788899.md), [Coverage/ENPSC12345](Coverage-ENPSC12345.md) and [Coverage/entitlement-3](Coverage-entitlement-3.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.org.nz.fhir.ig.nes|current/StructureDefinition/NesEntitlement)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-NesEntitlement.csv), [Excel](StructureDefinition-NesEntitlement.xlsx), [Schematron](StructureDefinition-NesEntitlement.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "NesEntitlement",
  "url" : "http://hl7.org.nz/fhir/StructureDefinition/NesEntitlement",
  "version" : "1.4.10",
  "name" : "NesEntitlement",
  "title" : "NES Entitlements",
  "status" : "active",
  "date" : "2025-12-09T01:41:12+00:00",
  "publisher" : "Te Whatu Ora",
  "contact" : [
    {
      "name" : "Te Whatu Ora",
      "telecom" : [
        {
          "system" : "email",
          "value" : "mailto:integration@health.govt.nz"
        }
      ]
    }
  ],
  "description" : "The coverage resource contains information related to Patient entitlements",
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "workflow",
      "uri" : "http://hl7.org/fhir/workflow",
      "name" : "Workflow Pattern"
    },
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    },
    {
      "identity" : "w5",
      "uri" : "http://hl7.org/fhir/fivews",
      "name" : "FiveWs Pattern Mapping"
    },
    {
      "identity" : "cdanetv4",
      "uri" : "http://www.cda-adc.ca/en/services/cdanet/",
      "name" : "Canadian Dental Association eclaims standard"
    },
    {
      "identity" : "v2",
      "uri" : "http://hl7.org/v2",
      "name" : "HL7 v2 Mapping"
    },
    {
      "identity" : "cpha3pharm",
      "uri" : "http://www.pharmacists.ca/",
      "name" : "Canadian Pharmacy Associaiton eclaims standard"
    }
  ],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Coverage",
  "baseDefinition" : "http://hl7.org.nz/fhir/StructureDefinition/NzCoverage",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "Coverage",
        "path" : "Coverage",
        "constraint" : [
          {
            "key" : "COVERAGE-STATUS-ALLOWED-CODES",
            "severity" : "error",
            "human" : "draft status is not allowed",
            "expression" : "Coverage.status.all(matches('draft').not())",
            "source" : "http://hl7.org.nz/fhir/StructureDefinition/NesEntitlement"
          },
          {
            "key" : "COVERAGE-URL-ALLOWED-CHARS",
            "severity" : "error",
            "human" : "character restrictions for URLs",
            "expression" : "Coverage.descendants().url.all(matches('^[-a-zA-Z0-9@:%._~#=?&\\/]*$'))",
            "source" : "http://hl7.org.nz/fhir/StructureDefinition/NesEntitlement"
          },
          {
            "key" : "COVERAGE-SYSTEM-LENGTH",
            "severity" : "error",
            "human" : "System URLs must be less than 1024 characters",
            "expression" : "Coverage.descendants().system.all(length()<1024)",
            "source" : "http://hl7.org.nz/fhir/StructureDefinition/NesEntitlement"
          },
          {
            "key" : "COVERAGE-SYSTEM-ALLOWED-CHARS",
            "severity" : "error",
            "human" : "character restrictions for system url",
            "expression" : "Coverage.descendants().system.all(matches('^[-a-zA-Z0-9@:%._~#=?&\\/]*$'))",
            "source" : "http://hl7.org.nz/fhir/StructureDefinition/NesEntitlement"
          },
          {
            "key" : "COVERAGE-CODEABLE-CONCEPT-TEXT-LENGTH",
            "severity" : "error",
            "human" : "valueCodeableConcept.text must be less than 1024 characters",
            "expression" : "Coverage.descendants().valueCodeableConcept.text.all(length()<1024)",
            "source" : "http://hl7.org.nz/fhir/StructureDefinition/NesEntitlement"
          },
          {
            "key" : "COVERAGE-CODEABLE-CONCEPT-TEXT-ALLOWED-CHARS",
            "severity" : "error",
            "human" : "character restrictions for valueCodeableConcept.text",
            "expression" : "Coverage.descendants().valueCodeableConcept.text.all(matches('^([-a-zA-Z0-9\\' \\t\\r\\n.\\/,])*$'))",
            "source" : "http://hl7.org.nz/fhir/StructureDefinition/NesEntitlement"
          }
        ]
      },
      {
        "id" : "Coverage.id",
        "path" : "Coverage.id",
        "short" : "Logical id of this artifact (The Entitlement.id)"
      },
      {
        "id" : "Coverage.implicitRules",
        "path" : "Coverage.implicitRules",
        "max" : "0"
      },
      {
        "id" : "Coverage.language",
        "path" : "Coverage.language",
        "max" : "0"
      },
      {
        "id" : "Coverage.contained",
        "path" : "Coverage.contained",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "type",
              "path" : "$this"
            }
          ],
          "rules" : "closed"
        }
      },
      {
        "id" : "Coverage.contained:beneficiary",
        "path" : "Coverage.contained",
        "sliceName" : "beneficiary",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Patient",
            "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/NesPatient"]
          }
        ]
      },
      {
        "id" : "Coverage.identifier",
        "path" : "Coverage.identifier",
        "short" : "Business Identifier for the Entitlement",
        "definition" : "A unique identifier assigned to this Entitlement (the card number)."
      },
      {
        "id" : "Coverage.identifier.id",
        "path" : "Coverage.identifier.id",
        "max" : "0"
      },
      {
        "id" : "Coverage.identifier.extension",
        "path" : "Coverage.identifier.extension",
        "max" : "0"
      },
      {
        "id" : "Coverage.identifier.use",
        "path" : "Coverage.identifier.use",
        "fixedCode" : "official"
      },
      {
        "id" : "Coverage.identifier.type",
        "path" : "Coverage.identifier.type",
        "max" : "0"
      },
      {
        "id" : "Coverage.identifier.system",
        "path" : "Coverage.identifier.system",
        "binding" : {
          "strength" : "required",
          "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/nes-entitlement-identifier-code"
        }
      },
      {
        "id" : "Coverage.identifier.period",
        "path" : "Coverage.identifier.period",
        "max" : "0"
      },
      {
        "id" : "Coverage.identifier.assigner",
        "path" : "Coverage.identifier.assigner",
        "max" : "0"
      },
      {
        "id" : "Coverage.status",
        "path" : "Coverage.status",
        "short" : "active | cancelled",
        "definition" : "The status of entitlement, derived from the start and end dates. Cancelled = ended entitlements."
      },
      {
        "id" : "Coverage.type",
        "path" : "Coverage.type",
        "short" : "Entitlement type such as CSC or HUHC.",
        "definition" : "The type of the Entitlement for example community services card (CSC) or high user health card (HUHC).",
        "binding" : {
          "strength" : "required",
          "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/coverage-type-code|1.1.0"
        }
      },
      {
        "id" : "Coverage.policyHolder",
        "path" : "Coverage.policyHolder",
        "max" : "0"
      },
      {
        "id" : "Coverage.subscriber",
        "path" : "Coverage.subscriber",
        "max" : "0"
      },
      {
        "id" : "Coverage.subscriberId",
        "path" : "Coverage.subscriberId",
        "max" : "0"
      },
      {
        "id" : "Coverage.beneficiary",
        "path" : "Coverage.beneficiary",
        "short" : "The Health service user's NHI.",
        "definition" : "The NHI number of the person who benefits from the entitlement",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/NesPatient"]
          }
        ]
      },
      {
        "id" : "Coverage.dependent",
        "path" : "Coverage.dependent",
        "max" : "0"
      },
      {
        "id" : "Coverage.relationship",
        "path" : "Coverage.relationship",
        "short" : "Used to identify a CSC dependent",
        "definition" : "An attribute used to identify if this entitlement is dependent on another CSC entitlement. Child for  CSC-dep"
      },
      {
        "id" : "Coverage.period",
        "path" : "Coverage.period",
        "short" : "Entitlement Start and Expiry or End date",
        "definition" : "Time period of the entitlement. Period Start = Entitlement start date. Period end = Entitlement expiry date (active entitlements) or Entitlement end date (ended entitlements)."
      },
      {
        "id" : "Coverage.payor",
        "path" : "Coverage.payor",
        "short" : "Organisation approving the entitlement.",
        "definition" : "The HPI Org Id for the organisation approving a Patient Entitlement."
      },
      {
        "id" : "Coverage.class",
        "path" : "Coverage.class",
        "max" : "0"
      },
      {
        "id" : "Coverage.order",
        "path" : "Coverage.order",
        "max" : "0"
      },
      {
        "id" : "Coverage.network",
        "path" : "Coverage.network",
        "max" : "0"
      },
      {
        "id" : "Coverage.costToBeneficiary",
        "path" : "Coverage.costToBeneficiary",
        "max" : "0"
      },
      {
        "id" : "Coverage.subrogation",
        "path" : "Coverage.subrogation",
        "max" : "0"
      },
      {
        "id" : "Coverage.contract",
        "path" : "Coverage.contract",
        "max" : "0"
      }
    ]
  }
}

```
