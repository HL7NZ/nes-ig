# NESCapabilityStatement - New Zealand NES IG v1.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NESCapabilityStatement**

## CapabilityStatement: NESCapabilityStatement 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org.nz/fhir/ig/nes/CapabilityStatement/NESCapabilityStatement | *Version*:1.5.0 |
| Draft as of 2023-05-24 | *Computable Name*: |

 
NES FHIR Capabilities 

 [Raw OpenAPI-Swagger Definition file](NESCapabilityStatement.openapi.json) | [Download](NESCapabilityStatement.openapi.json) 



## Resource Content

```json
{
  "resourceType" : "CapabilityStatement",
  "id" : "NESCapabilityStatement",
  "url" : "http://hl7.org.nz/fhir/ig/nes/CapabilityStatement/NESCapabilityStatement",
  "version" : "1.5.0",
  "status" : "draft",
  "date" : "2023-05-24",
  "publisher" : "Te Whatu Ora",
  "contact" : [{
    "name" : "Te Whatu Ora",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:integration@health.govt.nz"
    }]
  }],
  "description" : "NES FHIR Capabilities",
  "kind" : "requirements",
  "fhirVersion" : "4.0.1",
  "format" : ["json"],
  "patchFormat" : ["json"],
  "rest" : [{
    "mode" : "server",
    "resource" : [{
      "type" : "Coverage",
      "profile" : "http://hl7.org.nz/fhir/StructureDefinition/NzCoverage",
      "interaction" : [{
        "code" : "read",
        "documentation" : "GET,[base]/Coverage/[id],Used to retrieve a Patient entitlement by id, system/Coverage.r"
      },
      {
        "code" : "create",
        "documentation" : "POST,[base]/Coverage, Create a new entitlement, system/Coverage.c"
      },
      {
        "code" : "update",
        "documentation" : "PUT,[base]/Coverage/[id], Update a patient's entitlement card details, system/Coverage.u"
      },
      {
        "code" : "search-type",
        "documentation" : "GET,[base]/Coverage, Search for a patient's entitlements,patient:Coverage.s system/Coverage.s"
      }],
      "searchParam" : [{
        "name" : "identifier",
        "type" : "token",
        "documentation" : "external entitlement id - Future scope"
      },
      {
        "name" : "beneficiary",
        "type" : "string",
        "documentation" : "NHI-Id"
      },
      {
        "name" : "type",
        "type" : "token",
        "documentation" : "entitlement type code - Future scope"
      },
      {
        "name" : "status",
        "type" : "token",
        "documentation" : "status code - Future scope"
      }]
    },
    {
      "type" : "EpisodeOfCare",
      "profile" : "http://hl7.org.nz/fhir/StructureDefinition/NesEnrolment",
      "interaction" : [{
        "code" : "read",
        "documentation" : "GET,[base]/EpisodeOfCare/[id],Used to retrieve a Patient enrolment by id - Future scope, system/EpisodeOfCare.r"
      },
      {
        "code" : "create",
        "documentation" : "POST,[base]/EpisodeOfCare, Create a new enrolment, system/EpisodeOfCare.c"
      },
      {
        "code" : "update",
        "documentation" : "PUT,[base]/EpisodeOfCare/[id], Update an existing enrolment, system/EpisodeOfCare.u"
      },
      {
        "code" : "search-type",
        "documentation" : "GET,[base]/EpisodeOfCare, Search for a Patient's enrolment's, system/EpisodeOfCare.s"
      }]
    },
    {
      "type" : "Flag",
      "profile" : "http://hl7.org.nz/fhir/StructureDefinition/NesFlag",
      "interaction" : [{
        "code" : "search-type",
        "documentation" : "GET,[base]/Flag, Search for a Patient's NES Flags. Returns active flags only (end date null or in future), system/Flag.s"
      }],
      "searchParam" : [{
        "name" : "subject",
        "type" : "string",
        "documentation" : "NHI-Id"
      }]
    }],
    "operation" : [{
      "name" : "process-message",
      "definition" : "http://hl7.org/fhir/OperationDefinition/MessageHeader-process-message",
      "documentation" : "POST, [base]/$process-message, http://hl7.org/fhir/OperationDefinition/MessageHeader-process-message, system/MessageHeader.c"
    }]
  }],
  "messaging" : [{
    "supportedMessage" : [{
      "mode" : "sender",
      "definition" : "http://hl7.org.nz/fhir/MessageDefinition/EnrolmentNominationRequestMessageDefinition"
    },
    {
      "mode" : "receiver",
      "definition" : "http://hl7.org.nz/fhir/MessageDefinition/EnrolmentNominationRequestMessageDefinition"
    },
    {
      "mode" : "receiver",
      "definition" : "http://hl7.org.nz/fhir/MessageDefinition/EnrolmentNominationResponseMessageDefinition"
    }]
  }]
}

```
