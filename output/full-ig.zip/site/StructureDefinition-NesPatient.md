# NES Patient - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NES Patient**

## Resource Profile: NES Patient 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org.nz/fhir/StructureDefinition/NesPatient | *Version*:1.4.10 |
| Active as of 2025-12-09 | *Computable Name*:NesPatient |

 
A minimal profile of NzPatient, containing just enough information to validate a patient's NHI for the purposes of enrolment 

**Usages:**

* Use this Profile: [NES Enrolment](StructureDefinition-NesEnrolment.md) and [NES Entitlements](StructureDefinition-NesEntitlement.md)
* Refer to this Profile: [NES Enrolment](StructureDefinition-NesEnrolment.md) and [NES Entitlements](StructureDefinition-NesEntitlement.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.org.nz.fhir.ig.nes|current/StructureDefinition/NesPatient)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-NesPatient.csv), [Excel](StructureDefinition-NesPatient.xlsx), [Schematron](StructureDefinition-NesPatient.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "NesPatient",
  "url" : "http://hl7.org.nz/fhir/StructureDefinition/NesPatient",
  "version" : "1.4.10",
  "name" : "NesPatient",
  "title" : "NES Patient",
  "status" : "active",
  "date" : "2025-12-09T01:41:12+00:00",
  "publisher" : "Te Whatu Ora",
  "contact" : [
    {
      "name" : "Te Whatu Ora",
      "telecom" : [
        {
          "system" : "email",
          "value" : "mailto:integration@health.govt.nz"
        }
      ]
    }
  ],
  "description" : "A minimal profile of NzPatient, containing just enough information to validate a patient's NHI for the purposes of enrolment",
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    },
    {
      "identity" : "cda",
      "uri" : "http://hl7.org/v3/cda",
      "name" : "CDA (R2)"
    },
    {
      "identity" : "w5",
      "uri" : "http://hl7.org/fhir/fivews",
      "name" : "FiveWs Pattern Mapping"
    },
    {
      "identity" : "v2",
      "uri" : "http://hl7.org/v2",
      "name" : "HL7 v2 Mapping"
    },
    {
      "identity" : "loinc",
      "uri" : "http://loinc.org",
      "name" : "LOINC code for the element"
    }
  ],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Patient",
  "baseDefinition" : "http://hl7.org.nz/fhir/StructureDefinition/NzPatient",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "Patient.language",
        "path" : "Patient.language",
        "max" : "0"
      },
      {
        "id" : "Patient.extension:ethnicity",
        "path" : "Patient.extension",
        "sliceName" : "ethnicity",
        "max" : "0"
      },
      {
        "id" : "Patient.extension:nzCitizen",
        "path" : "Patient.extension",
        "sliceName" : "nzCitizen",
        "max" : "0"
      },
      {
        "id" : "Patient.extension:dhb",
        "path" : "Patient.extension",
        "sliceName" : "dhb",
        "max" : "0"
      },
      {
        "id" : "Patient.extension:domicile-code",
        "path" : "Patient.extension",
        "sliceName" : "domicile-code",
        "max" : "0"
      },
      {
        "id" : "Patient.extension:pho",
        "path" : "Patient.extension",
        "sliceName" : "pho",
        "max" : "0"
      },
      {
        "id" : "Patient.extension:sex-at-birth",
        "path" : "Patient.extension",
        "sliceName" : "sex-at-birth",
        "max" : "0"
      },
      {
        "id" : "Patient.extension:iwi",
        "path" : "Patient.extension",
        "sliceName" : "iwi",
        "max" : "0"
      },
      {
        "id" : "Patient.identifier",
        "path" : "Patient.identifier",
        "max" : "0"
      },
      {
        "id" : "Patient.identifier:NHI",
        "path" : "Patient.identifier",
        "sliceName" : "NHI",
        "max" : "0"
      },
      {
        "id" : "Patient.active",
        "path" : "Patient.active",
        "max" : "0"
      },
      {
        "id" : "Patient.telecom",
        "path" : "Patient.telecom",
        "max" : "0"
      },
      {
        "id" : "Patient.gender",
        "path" : "Patient.gender",
        "max" : "0"
      },
      {
        "id" : "Patient.deceased[x]",
        "path" : "Patient.deceased[x]",
        "max" : "0"
      },
      {
        "id" : "Patient.address",
        "path" : "Patient.address",
        "max" : "0"
      },
      {
        "id" : "Patient.maritalStatus",
        "path" : "Patient.maritalStatus",
        "max" : "0"
      },
      {
        "id" : "Patient.multipleBirth[x]",
        "path" : "Patient.multipleBirth[x]",
        "max" : "0"
      },
      {
        "id" : "Patient.photo",
        "path" : "Patient.photo",
        "max" : "0"
      },
      {
        "id" : "Patient.contact",
        "path" : "Patient.contact",
        "max" : "0"
      },
      {
        "id" : "Patient.generalPractitioner",
        "path" : "Patient.generalPractitioner",
        "max" : "0"
      },
      {
        "id" : "Patient.managingOrganization",
        "path" : "Patient.managingOrganization",
        "max" : "0"
      },
      {
        "id" : "Patient.link",
        "path" : "Patient.link",
        "max" : "0"
      }
    ]
  }
}

```
