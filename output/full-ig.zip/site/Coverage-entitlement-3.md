# entitlement-3 - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **entitlement-3**

## Example Coverage: entitlement-3

Profile: [NES Entitlements](StructureDefinition-NesEntitlement.md)

**identifier**: `https://standards.digital.health.nz/ns/nes-csc-id`/CSC12345 (use: official, )

**status**: Active

**type**: Community Services Card

**beneficiary**: [Patient/ZAA0792](Patient/ZAA0792)

**period**: 2023-08-27 --> 2024-08-27

**payor**: [Organization/GZZ998-G](Organization/GZZ998-G)



## Resource Content

```json
{
  "resourceType" : "Coverage",
  "id" : "entitlement-3",
  "meta" : {
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/NesEntitlement"]
  },
  "identifier" : [
    {
      "use" : "official",
      "system" : "https://standards.digital.health.nz/ns/nes-csc-id",
      "value" : "CSC12345"
    }
  ],
  "status" : "active",
  "type" : {
    "coding" : [
      {
        "system" : "https://standards.digital.health.nz/ns/coverage-type-code",
        "code" : "csc"
      }
    ]
  },
  "beneficiary" : {
    "reference" : "Patient/ZAA0792"
  },
  "period" : {
    "start" : "2023-08-27",
    "end" : "2024-08-27"
  },
  "payor" : [
    {
      "reference" : "Organization/GZZ998-G"
    }
  ]
}

```
