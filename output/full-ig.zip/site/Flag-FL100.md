# flag-1 - New Zealand NES IG v1.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **flag-1**

## Example Flag: flag-1

Profile: [NesFlag](StructureDefinition-NesFlag.md)

**identifier**: FL100

**status**: Active

**code**: https://health.govt.nz/NCCIsomething

**subject**: [Patient/ZJM9397](Patient/ZJM9397)

**period**: 2020-08-27 --> (ongoing)



## Resource Content

```json
{
  "resourceType" : "Flag",
  "id" : "FL100",
  "meta" : {
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/NesFlag"]
  },
  "identifier" : [{
    "value" : "FL100"
  }],
  "status" : "active",
  "code" : {
    "coding" : [{
      "system" : "https://standards.digital.health.nz/nes-flag-type",
      "code" : "NCCI"
    }],
    "text" : "https://health.govt.nz/NCCIsomething"
  },
  "subject" : {
    "reference" : "Patient/ZJM9397"
  },
  "period" : {
    "start" : "2020-08-27"
  }
}

```
