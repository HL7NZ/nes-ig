# Enrolment_encounter - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Enrolment_encounter**

## Extension: Enrolment_encounter 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org.nz/fhir/StructureDefinition/enrolment-encounter | *Version*:1.4.10 |
| Draft as of 2025-12-09 | *Computable Name*:Enrolment_encounter |

The last qualified encounter foe this enrolment

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [NES Enrolment](StructureDefinition-NesEnrolment.md)
* Examples for this Extension: [EpisodeOfCare/EN12349876](EpisodeOfCare-EN12349876.md) and [EpisodeOfCare/EN667788899](EpisodeOfCare-EN667788899.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.org.nz.fhir.ig.nes|current/StructureDefinition/enrolment-encounter)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-enrolment-encounter.csv), [Excel](StructureDefinition-enrolment-encounter.xlsx), [Schematron](StructureDefinition-enrolment-encounter.sch) 

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "enrolment-encounter",
  "url" : "http://hl7.org.nz/fhir/StructureDefinition/enrolment-encounter",
  "version" : "1.4.10",
  "name" : "Enrolment_encounter",
  "status" : "draft",
  "date" : "2025-12-09T01:41:12+00:00",
  "publisher" : "Te Whatu Ora",
  "contact" : [
    {
      "name" : "Te Whatu Ora",
      "telecom" : [
        {
          "system" : "email",
          "value" : "mailto:integration@health.govt.nz"
        }
      ]
    }
  ],
  "description" : "The last qualified encounter foe this enrolment",
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    }
  ],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [
    {
      "type" : "element",
      "expression" : "EpisodeOfCare"
    }
  ],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "Extension",
        "path" : "Extension",
        "definition" : "The last qualified encounter foe this enrolment"
      },
      {
        "id" : "Extension.extension",
        "path" : "Extension.extension",
        "max" : "0"
      },
      {
        "id" : "Extension.url",
        "path" : "Extension.url",
        "fixedUri" : "http://hl7.org.nz/fhir/StructureDefinition/enrolment-encounter"
      },
      {
        "id" : "Extension.value[x]",
        "path" : "Extension.value[x]",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Encounter"]
          }
        ]
      }
    ]
  }
}

```
