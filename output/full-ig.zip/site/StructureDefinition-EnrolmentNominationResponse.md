# EnrolmentNominationResponse - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EnrolmentNominationResponse**

## Resource Profile: EnrolmentNominationResponse 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org.nz/fhir/StructureDefinition/EnrolmentNominationResponse | *Version*:1.4.10 |
| Active as of 2025-12-09 | *Computable Name*:EnrolmentNominationResponse |

 
Adds additional, NES specific extensions 

**Usages:**

* This Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.org.nz.fhir.ig.nes|current/StructureDefinition/EnrolmentNominationResponse)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-EnrolmentNominationResponse.csv), [Excel](StructureDefinition-EnrolmentNominationResponse.xlsx), [Schematron](StructureDefinition-EnrolmentNominationResponse.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "EnrolmentNominationResponse",
  "url" : "http://hl7.org.nz/fhir/StructureDefinition/EnrolmentNominationResponse",
  "version" : "1.4.10",
  "name" : "EnrolmentNominationResponse",
  "title" : "EnrolmentNominationResponse",
  "status" : "active",
  "date" : "2025-12-09T01:41:12+00:00",
  "publisher" : "Te Whatu Ora",
  "contact" : [
    {
      "name" : "Te Whatu Ora",
      "telecom" : [
        {
          "system" : "email",
          "value" : "mailto:integration@health.govt.nz"
        }
      ]
    }
  ],
  "description" : "Adds additional, NES specific extensions",
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    },
    {
      "identity" : "v2",
      "uri" : "http://hl7.org/v2",
      "name" : "HL7 v2 Mapping"
    }
  ],
  "kind" : "resource",
  "abstract" : false,
  "type" : "OperationOutcome",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/OperationOutcome",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "OperationOutcome",
        "path" : "OperationOutcome"
      },
      {
        "id" : "OperationOutcome.issue.details",
        "path" : "OperationOutcome.issue.details",
        "binding" : {
          "strength" : "required",
          "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/enrolment-nomination-result"
        }
      }
    ]
  }
}

```
