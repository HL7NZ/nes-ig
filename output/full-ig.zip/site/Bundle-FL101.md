# flag-bundle-1 - New Zealand NES IG v1.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **flag-bundle-1**

## Example Bundle: flag-bundle-1



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "FL101",
  "meta" : {
    "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/NesFlag"]
  },
  "identifier" : {
    "value" : "FL102"
  },
  "type" : "searchset",
  "entry" : [{
    "resource" : {
      "resourceType" : "Flag",
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Flag_null\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Flag </b></p><p><b>status</b>: Active</p><p><b>code</b>: <span title=\"Codes:{https://standards.digital.health.nz/nes-flag-type CNC}\">see this url for guidance https://something </span></p><p><b>subject</b>: <a href=\"Patient/ZJM9397\">Patient/ZJM9397</a></p><p><b>period</b>: 2020-08-27 --&gt; 2026-08-27</p></div>"
      },
      "status" : "active",
      "code" : {
        "coding" : [{
          "system" : "https://standards.digital.health.nz/nes-flag-type",
          "code" : "CNC"
        }],
        "text" : "see this url for guidance https://something "
      },
      "subject" : {
        "reference" : "Patient/ZJM9397"
      },
      "period" : {
        "start" : "2020-08-27",
        "end" : "2026-08-27"
      }
    }
  }]
}

```
