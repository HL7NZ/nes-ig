# Extensions - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* **Extensions**

## Extensions

**Extensions defined in this guide**

* Id: [enrolment-encounter](StructureDefinition-enrolment-encounter.md)
  * Url: http://hl7.org.nz/fhir/StructureDefinition/enrolment-encounter
  * Context of Use: EpisodeOfCare
  * Description: The last qualified encounter foe this enrolment
  * Purpose: 
* Id: [enrolment-expiry-date](StructureDefinition-enrolment-expiry-date.md)
  * Url: http://hl7.org.nz/fhir/StructureDefinition/enrolment-expiry-date
  * Context of Use: EpisodeOfCare
  * Description: The enrolment expiry date
  * Purpose: 
* Id: [enrolment-owner-org](StructureDefinition-enrolment-owner-org.md)
  * Url: http://hl7.org.nz/fhir/StructureDefinition/enrolment-owner-org
  * Context of Use: EpisodeOfCare
  * Description: Org that creates the enrolment
  * Purpose: 
* Id: [nes-enrolment-termination-reason](StructureDefinition-nes-enrolment-termination-reason.md)
  * Url: http://hl7.org.nz/fhir/StructureDefinition/nes-enrolment-termination-reason
  * Context of Use: EpisodeOfCare
  * Description: NES Enrolment Termination Reason Code
  * Purpose: 
* Id: [reenrolment-date](StructureDefinition-reenrolment-date.md)
  * Url: http://hl7.org.nz/fhir/StructureDefinition/reenrolment-date
  * Context of Use: EpisodeOfCare
  * Description: The re-enrolment date
  * Purpose: 

