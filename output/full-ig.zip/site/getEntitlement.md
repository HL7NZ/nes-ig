# Get Entitlement - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* **Get Entitlement**

## Get Entitlement

### Get Entitlement by ID

#### Overview

The Get Entitlement operation allows an authorised user to retrieve an Entitlement record for a Patient using a known Entitlement record id.

#### Get Entitlement processing steps:

1. The user requests a specific Entitlement to be looked up.
1. The integrating application sends a GET request to the NES**Coverage**endpoint with the Entitlement id in the path
1. The request is validated - ALT: Validation failure. Operation Outcome resource returned
1. The entitlement is retrieved from the database
1. An NESEntitlement is returned to the client

#### Get Entitlement Response Example

[get entitlement response message 1](Coverage-EN667788899.json.md)

#### Get Entitlement Rules and Errors

* Rule: An Entitlement read request must include a valid Entitlement-id
  * Error code: * EM12020
* EM12021

  * Error description: * Entitlement cannot be found
* Invalid entitlement-id

  * Error text: * Entitlement cannot be found
* Invalid entitlement-id

  * Http code: * 404 Not found
* 400 Bad request


