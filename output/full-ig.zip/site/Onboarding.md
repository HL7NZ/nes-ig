# Onboarding - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* **Onboarding**

## Onboarding

### Enrolment and Entitlement Onboarding

#### Who can apply for access?

##### To the test environment:

Health professionals, agencies governed by the Health Information Privacy Code (HIPC) and their software vendors will be given access to the National Enrolment Service (NES) in the Health Identity Platform (HIP) Compliance environment for testing and training after completing the on-boarding process described below.

##### To the production environment:

Access to the NES is available to Health professionals and agencies governed by the Health Information Privacy Code (HIPC).

Each organisation and user that has access to the NES accepts their obligations under the Privacy Act 1993 and the Health Information Privacy Code 1994 to only access information about patients they are treating and are authorised to do so. NES information may also be accessed when assessing a patient’s eligibility for specific programmes, such as bowel and breast screening.

#### On-boarding and Implementation

1. To get started, head to['Consumer onboarding', over at the digital services hub](https://www.tewhatuora.govt.nz/health-services-and-programmes/digital-health/digital-services-hub/consumer-onboarding/). You will need to provide information about your organisation, the product you are developing and the API's you want to integrate with.
* For more information [have a look at the other resources on the Digital Service Hub](https://www.tewhatuora.govt.nz/health-services-and-programmes/digital-health/digital-services-hub/).

1. Once your onboarding request has been approved, you will be provided with the information to start integration. The integration team will be in touch if further information is required.
* You will receive your credentials, access token url, provided scopes, and the compliance environment endpoint.

1. Complete your development and testing.
1. When you are ready for compliance testing, email the[integration team](mailto:integration@tewhatuora.govt.nz)to get a compliance testing template.
1. Submit the results of the compliance tests using this form[HIP Compliance Submission](https://mohapis.atlassian.net/servicedesk/customer/portal/3/group/11/create/129).
1. The integration team will issue a compliance test report. Your application will receive certification to be used in production or additional requirements will need to be met.
* This can be an iterative process, so please get in touch as needed to discuss the compliance testing process.

1. **Each organisation**using your application with NHI integrated services must apply individually for access to the production environment (and recieve their own set of credentials) by completing the production form, please email[NHI Access](mailto:nhi_access@health.govt.nz).

* Please allow at least 5 working days for **compliance environment applications** to be processed.
* Please allow at least 2 weeks for **compliance testing** to be signed off and returned.
* If **Production credentials** are required by a large number of organisations accessing your product, please get in touch to discuss options around bulk credential requests and how we can streamline this process.

#### Assistance

Please fill in the [Digital Services Hub Support and Feedback form](https://mohapis.atlassian.net/servicedesk/customer/portal/3/group/35/create/112).

#### Business Functions

See below for available business functions.

By using Te Whatu Ora APIs you are accessing personally identifiable information from the NES which is not directly from the individual concerned. You need to consider your obligations under HIPC principle 2, and we may request to see your privacy impact assessment prior to access to production.

##### Business Functions

* Business Functions: FLS Read
  * Description: To allow access to get an FLS or FLS-NF enrolment by enrolment-id, or to get persons FLS or FLS-NF enrolment using NHI and other search parameters
  * Comments: [See Get Enrolment use case](getEnrolment.md)[See Search Enrolment use case](searchEnrolment.md)
* Business Functions: FLS Maintain
  * Description: Create and Update for FLS and FLS-NF enrolments
  * Comments: [See create Enrolment use case](createEnrolment.md)[See update Enrolment use case](updateEnrolment.md)
* Business Functions: LMC Read
  * Description: To allow access to get an LMC enrolment by enrolment-id, or to get persons LMC enrolment using NHI and other search parameters
  * Comments: [See Get Enrolment use case](getEnrolment.md)[See Search Enrolment use case](searchEnrolment.md)
* Business Functions: LMC Maintain
  * Description: Create and Update for LMC enrolments
  * Comments: [See create Enrolment use case](createEnrolment.md)[See update Enrolment use case](updateEnrolment.md)
* Business Functions: WCTO Read
  * Description: To allow access to get a WCTO enrolment by enrolment-id, or to get persons WCTO enrolments using NHI and other search parameters
  * Comments: [See Get Enrolment use case](getEnrolment.md)[See Search Enrolment use case](searchEnrolment.md)
* Business Functions: WCTO Maintain
  * Description: Create and Update for WCTO enrolments
  * Comments: [See create Enrolment use case](createEnrolment.md)[See update Enrolment use case](updateEnrolment.md)
* Business Functions: Health Entitlements Read
  * Description: Get a Patients Entitlement using identifier, orGet a Patient's Entitlement using NHI, with optional search parameters status and type
  * Comments: [See get Entitlement use case](getEntitlement.md)[See search Entitlement use case](searchEntitlement.md)
* Business Functions: Health Entitlements Maintain
  * Description: Create and Update Patient Health Entitlements
  * Comments: [See create Entitlement use case](createEntitlement.md)[See update Entitlement use case](updateEntitlement.md)

### New Born Enrolment Service

#### Who can apply for access?

##### To the test environment:

Maternity and related service providers and their software vendors will be given access to the Newborn Enrolment Service (NBES) in the Health Identity Platform (HIP) Compliance environment for testing and training after completing the on-boarding process described below.

##### To the production environment:

Access to the NBES is available to Maternity and related service providers who require the ability to send newborn enrolment nominations.

#### On-boarding and Implementation

1. To get started, head to['Consumer onboarding', over at the digital services hub](https://www.tewhatuora.govt.nz/health-services-and-programmes/digital-health/digital-services-hub/consumer-onboarding/). You will need to provide information about your organisation, the product you are developing and the API's you want to integrate with.
* For more information [have a look at the other resources on the Digital Service Hub](https://www.tewhatuora.govt.nz/health-services-and-programmes/digital-health/digital-services-hub/).

1. Once your onboarding request has been approved, you will be provided with the information to start integration. The integration team will be in touch if further information is required.
* You will receive your credentials, access token url, provided scopes, and the compliance environment endpoint.

1. Complete your development and testing.
1. When you are ready for compliance testing, email the[integration team](mailto:integration@tewhatuora.govt.nz)to get a compliance testing template.
1. Submit the results of the compliance tests using this form[HIP Compliance Submission](https://mohapis.atlassian.net/servicedesk/customer/portal/3/group/11/create/129).
1. The integration team will issue a compliance test report. Your application will receive certification to be used in production or additional requirements will need to be met.
* This can be an iterative process, so please get in touch as needed to discuss the compliance testing process.

1. **Each organisation**using your application with NHI integrated services must apply individually for access to the production environment (and recieve their own set of credentials) by completing the production form, please email[NHI Access](mailto:nhi_access@health.govt.nz).

Please allow at least 5 working days for these applications to be processed and production credentials issued. If your product is to be used by many different organisations please get in touch to discuss your rollout plans and how we might assist.

If you require help or have any questions regarding the onboarding process, please contact our team by completing a [General enquiry form](https://mohapis.atlassian.net/servicedesk/customer/portal/3/group/35/create/112).

#### Business Functions

See below for available business functions.
 By using Te Whatu Ora APIs you are accessing personally identifiable information from the NES which is not directly from the individual concerned. You need to consider your obligations under HIPC principle 2, and we may request to see your privacy impact assessment prior to access to production.

##### Business Functions

* Business Functions: Enrolment Nomination
  * Description: * The ability to send a newborn enrolment nomination message (Te Whatu Ora Whaihua platform users and Te Whatu Ora Enrolment nomination subscriber only). 
* The ability to respond to an enrolment nomination message (HealthLink only).

  * Comments: [See Enrolment Nomination use case](enrolmentNomination.md)

