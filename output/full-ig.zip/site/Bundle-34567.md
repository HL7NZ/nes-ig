# enrolment-nomination-response-message-1 - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **enrolment-nomination-response-message-1**

## Example Bundle: enrolment-nomination-response-message-1



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "34567",
  "meta" : {
    "tag" : [
      {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ProcessingID",
        "code" : "P"
      }
    ]
  },
  "type" : "message",
  "entry" : [
    {
      "fullUrl" : "34567",
      "resource" : {
        "resourceType" : "MessageHeader",
        "id" : "123123123",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_123123123\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader 123123123</b></p><a name=\"123123123\"> </a><a name=\"hc123123123\"> </a><p><b>event</b>: <a href=\"https://common-ig.hip.digital.health.nz/site/CodeSystem-nes-event-type-1.0.html#nes-event-type-1.0-FLS_ENROLMENT_NOMINATION_ACK\">NES Event Type: FLS_ENROLMENT_NOMINATION_ACK</a> (GP Enrolment Nomination Acknowledgement)</p><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Software</b></td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td>facid123</td><td>HSAP22222</td><td>pmsedi</td></tr></table><h3>Responses</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Identifier</b></td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td>66778899</td><td>OK</td></tr></table><p><b>focus</b>: <a href=\"Bundle-34567.html#OperationOutcome_success\">OperationOutcome</a></p></div>"
        },
        "eventCoding" : {
          "system" : "https://standards.digital.health.nz/ns/nes-event-type",
          "code" : "FLS_ENROLMENT_NOMINATION_ACK"
        },
        "source" : {
          "name" : "facid123",
          "software" : "HSAP22222",
          "endpoint" : "pmsedi"
        },
        "response" : {
          "identifier" : "66778899",
          "code" : "ok"
        },
        "focus" : [
          {
            "reference" : "OperationOutcome/success"
          }
        ]
      }
    },
    {
      "fullUrl" : "OperationOutcome/success",
      "resource" : {
        "resourceType" : "OperationOutcome",
        "id" : "success",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"OperationOutcome_success\"> </a><p class=\"res-header-id\"><b>Generated Narrative: OperationOutcome success</b></p><a name=\"success\"> </a><a name=\"hcsuccess\"> </a><h3>Issues</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Severity</b></td><td><b>Code</b></td><td><b>Details</b></td><td><b>Diagnostics</b></td></tr><tr><td style=\"display: none\">*</td><td>Information</td><td>Informational Note</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0008 AA}\">Original mode: Application Accept - Enhanced mode: Application acknowledgment: Accept</span></td><td>accepted</td></tr></table></div>"
        },
        "issue" : [
          {
            "severity" : "information",
            "code" : "informational",
            "details" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0008",
                  "code" : "AA"
                }
              ]
            },
            "diagnostics" : "accepted"
          }
        ]
      }
    }
  ]
}

```
