# Enrolment_expiry_date - New Zealand NES IG v1.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Enrolment_expiry_date**

## Extension: Enrolment_expiry_date 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org.nz/fhir/StructureDefinition/enrolment-expiry-date | *Version*:1.5.0 |
| Draft as of 2026-05-19 | *Computable Name*:Enrolment_expiry_date |

The enrolment expiry date

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [NES Enrolment](StructureDefinition-NesEnrolment.md)
* Examples for this Extension: [EpisodeOfCare/EN12349876](EpisodeOfCare-EN12349876.md), [EpisodeOfCare/EN667788899](EpisodeOfCare-EN667788899.md) and [EpisodeOfCare/do-not-populate-id](EpisodeOfCare-do-not-populate-id.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.org.nz.fhir.ig.nes|current/StructureDefinition/enrolment-expiry-date)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-enrolment-expiry-date.csv), [Excel](StructureDefinition-enrolment-expiry-date.xlsx), [Schematron](StructureDefinition-enrolment-expiry-date.sch) 

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "enrolment-expiry-date",
  "url" : "http://hl7.org.nz/fhir/StructureDefinition/enrolment-expiry-date",
  "version" : "1.5.0",
  "name" : "Enrolment_expiry_date",
  "status" : "draft",
  "date" : "2026-05-19T23:56:47+00:00",
  "publisher" : "Te Whatu Ora",
  "contact" : [{
    "name" : "Te Whatu Ora",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:integration@health.govt.nz"
    }]
  }],
  "description" : "The enrolment expiry date",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "EpisodeOfCare"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "definition" : "The enrolment expiry date"
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "http://hl7.org.nz/fhir/StructureDefinition/enrolment-expiry-date"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "type" : [{
        "code" : "date"
      }]
    }]
  }
}

```
