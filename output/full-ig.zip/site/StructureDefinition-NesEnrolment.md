# NES Enrolment - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **NES Enrolment**

## Resource Profile: NES Enrolment 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org.nz/fhir/StructureDefinition/NesEnrolment | *Version*:1.4.10 |
| Active as of 2025-12-09 | *Computable Name*:NesEnrolment |

 
Adds additional, NES specific extensions for enrolments 

**Usages:**

* CapabilityStatements using this Profile: [CapabilityStatement[http://hl7.org.nz/fhir/ig/nes/CapabilityStatement/NESCapabilityStatement|1.4.10]](CapabilityStatement-NESCapabilityStatement.md)
* This Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.org.nz.fhir.ig.nes|current/StructureDefinition/NesEnrolment)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-NesEnrolment.csv), [Excel](StructureDefinition-NesEnrolment.xlsx), [Schematron](StructureDefinition-NesEnrolment.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "NesEnrolment",
  "url" : "http://hl7.org.nz/fhir/StructureDefinition/NesEnrolment",
  "version" : "1.4.10",
  "name" : "NesEnrolment",
  "title" : "NES Enrolment",
  "status" : "active",
  "date" : "2025-12-09T01:41:12+00:00",
  "publisher" : "Te Whatu Ora",
  "contact" : [
    {
      "name" : "Te Whatu Ora",
      "telecom" : [
        {
          "system" : "email",
          "value" : "mailto:integration@health.govt.nz"
        }
      ]
    }
  ],
  "description" : "Adds additional, NES specific extensions for enrolments",
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "workflow",
      "uri" : "http://hl7.org/fhir/workflow",
      "name" : "Workflow Pattern"
    },
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    },
    {
      "identity" : "w5",
      "uri" : "http://hl7.org/fhir/fivews",
      "name" : "FiveWs Pattern Mapping"
    }
  ],
  "kind" : "resource",
  "abstract" : false,
  "type" : "EpisodeOfCare",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/EpisodeOfCare",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "EpisodeOfCare",
        "path" : "EpisodeOfCare",
        "constraint" : [
          {
            "key" : "URL-LENGTH",
            "severity" : "error",
            "human" : "URLs must be less than 1024 characters",
            "expression" : "EpisodeOfCare.descendants().url.all(length()<1024)",
            "source" : "http://hl7.org.nz/fhir/StructureDefinition/NesEnrolment"
          },
          {
            "key" : "URL-ALLOWED-CHARS",
            "severity" : "error",
            "human" : "character restrictions for URLs",
            "expression" : "EpisodeOfCare.descendants().url.all(matches('^[-a-zA-Z0-9@:%._~#=?&\\/]*$'))",
            "source" : "http://hl7.org.nz/fhir/StructureDefinition/NesEnrolment"
          },
          {
            "key" : "SYSTEM-LENGTH",
            "severity" : "error",
            "human" : "System URLs must be less than 1024 characters",
            "expression" : "EpisodeOfCare.descendants().system.all(length()<1024)",
            "source" : "http://hl7.org.nz/fhir/StructureDefinition/NesEnrolment"
          },
          {
            "key" : "SYSTEM-ALLOWED-CHARS",
            "severity" : "error",
            "human" : "character restrictions for system url",
            "expression" : "EpisodeOfCare.descendants().system.all(matches('^[-a-zA-Z0-9@:%._~#=?&\\/]*$'))",
            "source" : "http://hl7.org.nz/fhir/StructureDefinition/NesEnrolment"
          },
          {
            "key" : "CODEABLE-CONCEPT-TEXT-LENGTH",
            "severity" : "error",
            "human" : "valueCodeableConcept.text must be less than 1024 characters",
            "expression" : "EpisodeOfCare.descendants().valueCodeableConcept.text.all(length()<1024)",
            "source" : "http://hl7.org.nz/fhir/StructureDefinition/NesEnrolment"
          },
          {
            "key" : "CODEABLE-CONCEPT-TEXT-ALLOWED-CHARS",
            "severity" : "error",
            "human" : "character restrictions for valueCodeableConcept.text",
            "expression" : "EpisodeOfCare.descendants().valueCodeableConcept.text.all(matches('^([-a-zA-Z0-9\\' \\t\\r\\n.\\/,])*$'))",
            "source" : "http://hl7.org.nz/fhir/StructureDefinition/NesEnrolment"
          }
        ]
      },
      {
        "id" : "EpisodeOfCare.meta.versionId",
        "path" : "EpisodeOfCare.meta.versionId",
        "max" : "0"
      },
      {
        "id" : "EpisodeOfCare.meta.source",
        "path" : "EpisodeOfCare.meta.source",
        "max" : "0"
      },
      {
        "id" : "EpisodeOfCare.meta.security",
        "path" : "EpisodeOfCare.meta.security",
        "max" : "0"
      },
      {
        "id" : "EpisodeOfCare.meta.tag",
        "path" : "EpisodeOfCare.meta.tag",
        "max" : "0"
      },
      {
        "id" : "EpisodeOfCare.language",
        "path" : "EpisodeOfCare.language",
        "max" : "0"
      },
      {
        "id" : "EpisodeOfCare.contained",
        "path" : "EpisodeOfCare.contained",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "type",
              "path" : "$this"
            }
          ],
          "description" : "Slicing to specify a PractitionerRole resource may be returned as a contained resource for the Care Manager",
          "rules" : "closed"
        }
      },
      {
        "id" : "EpisodeOfCare.contained:careManager",
        "path" : "EpisodeOfCare.contained",
        "sliceName" : "careManager",
        "short" : "Contained resource for the last qualified Encounter relating to this Enrolment",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "PractitionerRole",
            "profile" : [
              "http://hl7.org.nz/fhir/StructureDefinition/NesPractitionerRole"
            ]
          }
        ]
      },
      {
        "id" : "EpisodeOfCare.contained:qualifiedEncounter",
        "path" : "EpisodeOfCare.contained",
        "sliceName" : "qualifiedEncounter",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Encounter"
          }
        ]
      },
      {
        "id" : "EpisodeOfCare.contained:patient",
        "path" : "EpisodeOfCare.contained",
        "sliceName" : "patient",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Patient",
            "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/NesPatient"]
          }
        ]
      },
      {
        "id" : "EpisodeOfCare.extension",
        "path" : "EpisodeOfCare.extension",
        "slicing" : {
          "discriminator" : [
            {
              "type" : "value",
              "path" : "url"
            }
          ],
          "ordered" : false,
          "rules" : "open"
        }
      },
      {
        "id" : "EpisodeOfCare.extension:expiryDate",
        "path" : "EpisodeOfCare.extension",
        "sliceName" : "expiryDate",
        "short" : "The date on which the Enrolment will expire",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Extension",
            "profile" : [
              "http://hl7.org.nz/fhir/StructureDefinition/enrolment-expiry-date"
            ]
          }
        ]
      },
      {
        "id" : "EpisodeOfCare.extension:re-enrolmentDate",
        "path" : "EpisodeOfCare.extension",
        "sliceName" : "re-enrolmentDate",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Extension",
            "profile" : [
              "http://hl7.org.nz/fhir/StructureDefinition/reenrolment-date"
            ]
          }
        ]
      },
      {
        "id" : "EpisodeOfCare.extension:owningOrganisation",
        "path" : "EpisodeOfCare.extension",
        "sliceName" : "owningOrganisation",
        "short" : "Organisation that creates the enrolment",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Extension",
            "profile" : [
              "http://hl7.org.nz/fhir/StructureDefinition/enrolment-owner-org"
            ]
          }
        ]
      },
      {
        "id" : "EpisodeOfCare.extension:terminationReason",
        "path" : "EpisodeOfCare.extension",
        "sliceName" : "terminationReason",
        "short" : " describe the reason the enrolment has ended",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Extension",
            "profile" : [
              "http://hl7.org.nz/fhir/StructureDefinition/nes-enrolment-termination-reason"
            ]
          }
        ]
      },
      {
        "id" : "EpisodeOfCare.extension:terminationReason.value[x]",
        "path" : "EpisodeOfCare.extension.value[x]",
        "binding" : {
          "strength" : "required",
          "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/nes-enrolment-termination-reason"
        }
      },
      {
        "id" : "EpisodeOfCare.extension:qualifiedEncounter",
        "path" : "EpisodeOfCare.extension",
        "sliceName" : "qualifiedEncounter",
        "short" : "the last qualified Encounter relating to this Enrolment",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Extension",
            "profile" : [
              "http://hl7.org.nz/fhir/StructureDefinition/enrolment-encounter"
            ]
          }
        ]
      },
      {
        "id" : "EpisodeOfCare.status",
        "path" : "EpisodeOfCare.status",
        "binding" : {
          "strength" : "required",
          "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/nes-episode-of-care-status"
        }
      },
      {
        "id" : "EpisodeOfCare.statusHistory",
        "path" : "EpisodeOfCare.statusHistory",
        "max" : "0"
      },
      {
        "id" : "EpisodeOfCare.type",
        "path" : "EpisodeOfCare.type",
        "binding" : {
          "strength" : "required",
          "valueSet" : "https://nzhts.digital.health.nz/fhir/ValueSet/nes-enrolment-type"
        }
      },
      {
        "id" : "EpisodeOfCare.diagnosis",
        "path" : "EpisodeOfCare.diagnosis",
        "max" : "0"
      },
      {
        "id" : "EpisodeOfCare.patient",
        "path" : "EpisodeOfCare.patient",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/NesPatient"]
          }
        ]
      },
      {
        "id" : "EpisodeOfCare.referralRequest",
        "path" : "EpisodeOfCare.referralRequest",
        "max" : "0"
      },
      {
        "id" : "EpisodeOfCare.team",
        "path" : "EpisodeOfCare.team",
        "max" : "0"
      },
      {
        "id" : "EpisodeOfCare.account",
        "path" : "EpisodeOfCare.account",
        "max" : "0"
      }
    ]
  }
}

```
