# enrolment-nomination-request-error-response-1 - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **enrolment-nomination-request-error-response-1**

## Example OperationOutcome: enrolment-nomination-request-error-response-1

### Issues

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Severity** | **Code** | **Details** |
| * | Error | Informational Note | The NHI cannot be found |



## Resource Content

```json
{
  "resourceType" : "OperationOutcome",
  "id" : "enrolment-nomination-request-error-response-1",
  "issue" : [
    {
      "severity" : "error",
      "code" : "informational",
      "details" : {
        "coding" : [
          {
            "system" : "https://standards.digital.health.nz/ns/hip-error-code",
            "code" : "EM02002"
          }
        ],
        "text" : "The NHI cannot be found"
      }
    }
  ]
}

```
