# enrolment-nomination-response-message-2 - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **enrolment-nomination-response-message-2**

## Example Bundle: enrolment-nomination-response-message-2



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "6789",
  "meta" : {
    "tag" : [
      {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ProcessingID",
        "code" : "P"
      }
    ]
  },
  "type" : "message",
  "entry" : [
    {
      "fullUrl" : "34567",
      "resource" : {
        "resourceType" : "MessageHeader",
        "id" : "321321321",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_321321321\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader 321321321</b></p><a name=\"321321321\"> </a><a name=\"hc321321321\"> </a><p><b>event</b>: <a href=\"https://common-ig.hip.digital.health.nz/site/CodeSystem-nes-event-type-1.0.html#nes-event-type-1.0-FLS_ENROLMENT_NOMINATION_ACK\">NES Event Type: FLS_ENROLMENT_NOMINATION_ACK</a> (GP Enrolment Nomination Acknowledgement)</p><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Name</b></td><td><b>Software</b></td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td>facid123</td><td>HSAP22222</td><td>pmsedi</td></tr></table><h3>Responses</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Identifier</b></td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td>66778899</td><td>OK</td></tr></table><p><b>focus</b>: <a href=\"Bundle-6789.html#OperationOutcome_error\">OperationOutcome</a></p></div>"
        },
        "eventCoding" : {
          "system" : "https://standards.digital.health.nz/ns/nes-event-type",
          "code" : "FLS_ENROLMENT_NOMINATION_ACK"
        },
        "source" : {
          "name" : "facid123",
          "software" : "HSAP22222",
          "endpoint" : "pmsedi"
        },
        "response" : {
          "identifier" : "66778899",
          "code" : "ok"
        },
        "focus" : [
          {
            "reference" : "OperationOutcome/error"
          }
        ]
      }
    },
    {
      "fullUrl" : "OperationOutcome/error",
      "resource" : {
        "resourceType" : "OperationOutcome",
        "id" : "error",
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"OperationOutcome_error\"> </a><p class=\"res-header-id\"><b>Generated Narrative: OperationOutcome error</b></p><a name=\"error\"> </a><a name=\"hcerror\"> </a><h3>Issues</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Severity</b></td><td><b>Code</b></td><td><b>Details</b></td><td><b>Diagnostics</b></td></tr><tr><td style=\"display: none\">*</td><td>Error</td><td>Processing Failure</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0008 AE}\">Original mode: Application Error - Enhanced mode: Application acknowledgment: Error</span></td><td>problem processing NK1 segment</td></tr></table></div>"
        },
        "issue" : [
          {
            "severity" : "error",
            "code" : "processing",
            "details" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0008",
                  "code" : "AE"
                }
              ]
            },
            "diagnostics" : "problem processing NK1 segment"
          }
        ]
      }
    }
  ]
}

```
