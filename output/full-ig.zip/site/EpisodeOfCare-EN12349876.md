# enrolment-2-ended - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **enrolment-2-ended**

## Example EpisodeOfCare: enrolment-2-ended



## Resource Content

```json
{
  "resourceType" : "EpisodeOfCare",
  "id" : "EN12349876",
  "contained" : [
    {
      "resourceType" : "PractitionerRole",
      "id" : "EnrolmentServiceProvider10",
      "practitioner" : {
        "reference" : "Practitioner/99ZZZS",
        "display" : "Mrs TestOne Prefix-Test"
      },
      "organization" : {
        "reference" : "Organization/GZZ998-G",
        "display" : "Live Org with Dormant"
      },
      "location" : [
        {
          "reference" : "Location/FZZ968-B",
          "display" : "Facility Has All Contact Types TEST"
        }
      ]
    },
    {
      "resourceType" : "Encounter",
      "id" : "QualifiedEncounter10",
      "status" : "finished",
      "class" : {
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
        "code" : "AMB"
      },
      "period" : {
        "start" : "2023-09-27"
      }
    },
    {
      "resourceType" : "Patient",
      "id" : "ZKC4633",
      "meta" : {
        "profile" : ["http://hl7.org.nz/fhir/StructureDefinition/NesPatient"]
      },
      "name" : [
        {
          "family" : "Aufderhar",
          "given" : ["Rickey", "Amalia"]
        }
      ],
      "birthDate" : "2021-12-29"
    }
  ],
  "extension" : [
    {
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/enrolment-encounter",
      "valueReference" : {
        "reference" : "#QualifiedEncounter10"
      }
    },
    {
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/enrolment-expiry-date",
      "valueDate" : "2026-06-05"
    },
    {
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/reenrolment-date",
      "valueDate" : "2022-06-05"
    },
    {
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/enrolment-owner-org",
      "valueReference" : {
        "reference" : "Organization/GZZ998-G",
        "display" : "Live Org with Dormant"
      }
    },
    {
      "url" : "http://hl7.org.nz/fhir/StructureDefinition/nes-enrolment-termination-reason",
      "valueCodeableConcept" : {
        "coding" : [
          {
            "system" : "https://standards.digital.health.nz/nes-enrolment-termination-reason",
            "code" : "LinkNHI"
          }
        ],
        "text" : "NHI was Linked"
      }
    }
  ],
  "identifier" : [
    {
      "system" : "https://standards.digital.health.nz/ns/nes-enrolment-id",
      "value" : "EN667788899"
    }
  ],
  "status" : "active",
  "type" : [
    {
      "coding" : [
        {
          "system" : "https://standards.digital.health.nz/nes-enrolment-type",
          "code" : "FLS-NF"
        }
      ]
    }
  ],
  "patient" : {
    "reference" : "#ZKC4633"
  },
  "careManager" : {
    "reference" : "#EnrolmentServiceProvider10"
  }
}

```
