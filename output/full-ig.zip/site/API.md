# API - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* **API**

## API

NES FHIR Capabilities

### REST APIs

#### Resource Level Interactions

##### Coverage

**Interactions**

* Name: read
  * Verb: GET
  * URL: [base]/Coverage/[id]
  * Documentation: Used to retrieve a Patient entitlement by id
  * Scope: system/Coverage.r
* Name: create
  * Verb: POST
  * URL: [base]/Coverage
  * Documentation: Create a new entitlement - Future Scope
  * Scope: system/Coverage.c
* Name: update
  * Verb: PUT
  * URL: [base]/Coverage/[id]
  * Documentation: Update a patient's entitlement card details
  * Scope: system/Coverage.u
* Name: search-type
  * Verb: GET
  * URL: [base]/Coverage
  * Documentation: Search for a patient's entitlements
  * Scope: patient:Coverage.s system/Coverage.s

**Search Parameters**

* Name: identifier
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: external entitlement id - Future scope
* Name: beneficiary
  * Type: [string](http://hl7.org/fhir/search.html#string)
  * Documentation: NHI-Id
* Name: type
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: entitlement type code - Future scope
* Name: status
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: status code - Future scope

##### EpisodeOfCare

**Interactions**

* Name: read
  * Verb: GET
  * URL: [base]/EpisodeOfCare/[id]
  * Documentation: Used to retrieve a Patient enrolment by id - Future scope
  * Scope: system/EpisodeOfCare.r
* Name: create
  * Verb: POST
  * URL: [base]/EpisodeOfCare
  * Documentation: Create a new enrolment
  * Scope: system/EpisodeOfCare.c
* Name: update
  * Verb: PUT
  * URL: [base]/EpisodeOfCare/[id]
  * Documentation: Update an existing enrolment
  * Scope: system/EpisodeOfCare.u
* Name: search-type
  * Verb: GET
  * URL: [base]/EpisodeOfCare
  * Documentation: Search for a Patient's enrolment's
  * Scope: system/EpisodeOfCare.s

**Search Parameters**

* Name: patient
  * Type: [string](http://hl7.org/fhir/search.html#string)
  * Documentation: NHI number
* Name: status
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: status code
* Name: type
  * Type: [token](http://hl7.org/fhir/search.html#token)
  * Documentation: type code - Future scope

#### Server Level Interactions

**Operations**

* Name: process-message
  * Verb: POST
  * URL: [base]/$process-message
  * Documentation: http://hl7.org/fhir/OperationDefinition/MessageHeader-process-message
  * Scope: system/MessageHeader.c

### Messages

**Definitions**

* Name: sender
  * Definitions: http://hl7.org.nz/fhir/MessageDefinition/EnrolmentNominationRequestMessageDefinition
* Name: receiver
  * Definitions: http://hl7.org.nz/fhir/MessageDefinition/EnrolmentNominationRequestMessageDefinition
* Name: receiver
  * Definitions: http://hl7.org.nz/fhir/MessageDefinition/EnrolmentNominationResponseMessageDefinition

