# Enrolment_owner_org - New Zealand NES IG v1.5.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Enrolment_owner_org**

## Extension: Enrolment_owner_org 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org.nz/fhir/StructureDefinition/enrolment-owner-org | *Version*:1.5.0 |
| Draft as of 2026-05-15 | *Computable Name*:Enrolment_owner_org |

Org that creates the enrolment

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [NES Enrolment](StructureDefinition-NesEnrolment.md)
* Examples for this Extension: [EpisodeOfCare/EN12349876](EpisodeOfCare-EN12349876.md), [EpisodeOfCare/EN667788899](EpisodeOfCare-EN667788899.md) and [EpisodeOfCare/do-not-populate-id](EpisodeOfCare-do-not-populate-id.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.org.nz.fhir.ig.nes|current/StructureDefinition/enrolment-owner-org)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-enrolment-owner-org.csv), [Excel](StructureDefinition-enrolment-owner-org.xlsx), [Schematron](StructureDefinition-enrolment-owner-org.sch) 

#### Constraints



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "enrolment-owner-org",
  "url" : "http://hl7.org.nz/fhir/StructureDefinition/enrolment-owner-org",
  "version" : "1.5.0",
  "name" : "Enrolment_owner_org",
  "status" : "draft",
  "date" : "2026-05-15T05:59:10+00:00",
  "publisher" : "Te Whatu Ora",
  "contact" : [{
    "name" : "Te Whatu Ora",
    "telecom" : [{
      "system" : "email",
      "value" : "mailto:integration@health.govt.nz"
    }]
  }],
  "description" : "Org that creates the enrolment",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "EpisodeOfCare"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "definition" : "Org that creates the enrolment"
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "http://hl7.org.nz/fhir/StructureDefinition/enrolment-owner-org"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org.nz/fhir/StructureDefinition/HPIOrganization"]
      }]
    }]
  }
}

```
