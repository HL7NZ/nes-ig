# Search Entitlement - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* **Search Entitlement**

## Search Entitlement

### Search Entitlements

#### Overview

This operation is used to return all entitlements for a person. The Entitlement service will return all active entitlements, end-dated entitlements will not be returned.

A person may have:

* one CSC entitlement.
* multiple CSC-dependent entitlements, if they are a dependent child and parents with a CSC each, or are part of multiple family units (Note: Cannot also have a CSC entitlement).
* multiple PSC entitlements (one for each family unit they belong to (if that family unit is eligible).

#### Get Entitlements for Patient processing steps:

1. The user requests a a persons entitlements using an NHI number.
1. The integrating application sends a GET request to the NES**Coverage**endpoint with the 'beneficiary' query parameter specifying the patient's NHI number.
1. The request is validated - ALT: Validation failure. Operation Outcome resource returned.
1. The entitlements is retrieved from the database.
1. A bundle of NESEntitlements is returned to the client.

#### Search Entitlement Response Example

For a search entitlement response example [click here](searchEntitlementResponse.md)

#### Search Entitlement Rules and Errors

* Rule: A search entitlement must include an NHI at minimum (Coverage.beneficiary)
  * Error code: 
  * Error description: 
  * Error text: 
  * Http code: 

