# EnrolmentNominationRequestMessageDefinition - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EnrolmentNominationRequestMessageDefinition**

## MessageDefinition: EnrolmentNominationRequestMessageDefinition 

| | |
| :--- | :--- |
| *Official URL*:http://hl7.org.nz/fhir/MessageDefinition/EnrolmentNominationRequestMessageDefinition | *Version*:1.4.10 |
| Draft as of 2020-04-21 | *Computable Name*: |

 
Defines the message used to request an enrolment 

**url**: [MessageDefinition: url = http://hl7.org.nz/fhir/MessageDefinition/EnrolmentNominationRequestMessageDefinition; version = 1.4.10; status = draft; date = 2020-04-21; publisher = Te Whatu Ora; contact = Te Whatu Ora (mailto:integration@health.govt.nz); description = Defines the message used to request an enrolment; jurisdiction = ; copyright = ; event[x] = GP Enrolment Nomination (NES Event Type#FLS_ENROLMENT_NOMINATION)](MessageDefinition-EnrolmentNominationRequestMessageDefinition.md)

**version**: 1.4.10

**status**: Draft

**date**: 2020-04-21

**publisher**: Te Whatu Ora

**contact**: Te Whatu Ora: [mailto:integration@health.govt.nz](mailto:mailto:integration@health.govt.nz)

**description**: 

Defines the message used to request an enrolment

**event**: [NES Event Type: FLS_ENROLMENT_NOMINATION](https://common-ig.hip.digital.health.nz/site/CodeSystem-nes-event-type-1.0.html#nes-event-type-1.0-FLS_ENROLMENT_NOMINATION) (GP Enrolment Nomination)

> **focus****code**: Patient**profile**:[NHI Patient](https://nhi-ig.hip.digital.health.nz/site/StructureDefinition-NhiPatient.html)**min**: 1**max**: 1

> **focus****code**: RelatedPerson**min**: 1**max**: 2

> **focus****code**: Practitioner**profile**:[HPI Practitioner](https://hpi-ig.hip-uat.digital.health.nz/StructureDefinition-HPIPractitioner.html)**min**: 0**max**: 1

### AllowedResponses

| | |
| :--- | :--- |
| - | **Message** |
| * | [MessageDefinition[http://hl7.org.nz/fhir/MessageDefinition/EnrolmentNominationResponseMessageDefinition|1.4.10]](MessageDefinition-EnrolmentNominationResponseMessageDefinition.md) |



## Resource Content

```json
{
  "resourceType" : "MessageDefinition",
  "id" : "EnrolmentNominationRequestMessageDefinition",
  "url" : "http://hl7.org.nz/fhir/MessageDefinition/EnrolmentNominationRequestMessageDefinition",
  "version" : "1.4.10",
  "status" : "draft",
  "date" : "2020-04-21",
  "publisher" : "Te Whatu Ora",
  "contact" : [
    {
      "name" : "Te Whatu Ora",
      "telecom" : [
        {
          "system" : "email",
          "value" : "mailto:integration@health.govt.nz"
        }
      ]
    }
  ],
  "description" : "Defines the message used to request an enrolment",
  "eventCoding" : {
    "system" : "https://standards.digital.health.nz/ns/nes-event-type",
    "code" : "FLS_ENROLMENT_NOMINATION"
  },
  "focus" : [
    {
      "code" : "Patient",
      "profile" : "http://hl7.org.nz/fhir/StructureDefinition/NhiPatient",
      "min" : 1,
      "max" : "1"
    },
    {
      "code" : "RelatedPerson",
      "min" : 1,
      "max" : "2"
    },
    {
      "code" : "Practitioner",
      "profile" : "http://hl7.org.nz/fhir/StructureDefinition/HPIPractitioner",
      "min" : 0,
      "max" : "1"
    }
  ],
  "allowedResponse" : [
    {
      "message" : "http://hl7.org.nz/fhir/MessageDefinition/EnrolmentNominationResponseMessageDefinition"
    }
  ]
}

```
