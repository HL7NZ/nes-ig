# Enrolment Nomination Compliance Testing - New Zealand NES IG v1.4.10

* [**Table of Contents**](toc.md)
* **Enrolment Nomination Compliance Testing**

## Enrolment Nomination Compliance Testing

#### Enrolment Nomination Request

* Reference: EnrolmentNominationRequest-1
  * Purpose: application can create an enrolment nomination request with the minimum set of enrolment nomination information
  * Input values: Send a nomination request for:* Baby 
* NHI: ZKS3307
* Gender: Female
* DOB: 2023-10-11
 
* GP 
* Facility ID: FZZ932-C
 
* PG1 
* Relationship Code: MTH
 

  * Expected outcome: 1. Input:Minimum set of nomination information can be provided
1. Output: Nomination request can be successfully posted to the NES $process-message endpoint
1. Get a success response of 200()

  * Mandatory: mandatory
* Reference: EnrolmentNominationRequest-2
  * Purpose: application can create an enrolment nomination request with all possible nomination information
  * Input values: Send a nomination request for:* Baby 
* NHI ZKS3340
* Name 
* Given name: Baby of Trentham
* Family name: Testing NBES Four
 
* Gender: unknown
* DOB: 2023-10-08
 
* GP 
* Facility ID: FZZ932-C
* Facility name: Facility for Private Hospital
 
* PG1 
* Relationship Code: MTH
* Given name: Maria
* Family name: Murtle
* NHI Number: ZKU8202
* Contact Number: 1234567
* Work number: 121234567
* Email: NBES@NBES.com
* Address: 31 King Street, Ebdentown, Upper Hutt, 5018
 

  * Expected outcome: 1. Input: All possible nomination information can be provided
1. Output: Nomination request can be successfully posted to the NES $process-message endpoint

  * Mandatory: mandatory

#### Enrolment Nomination Errors

* Reference: EnrolmentNomination-Error-1
  * Purpose: application will manage the error when attempting to send an enrolment nomination message that does not have the Baby’s NHI number
  * Input values: Send a nomination request for:* Baby 
* NHI: 'leave blank'
* Gender: Female
* DOB: 2023-10-11
 
* GP 
* Facility ID: FZZ932-C
 
* PG1 
* Relationship Code: MTH
 

  * Expected outcome: 1. Input:Input: enrolment nomination information can be provided
1. Output:Output: Error 422 Unprocessable entity

  * Mandatory: mandatory
* Reference: EnrolmentNomination-Error-2
  * Purpose: application will manage the error when attempting to send an enrolment nomination with an NHI number that cannot be found
  * Input values: Send a nomination request for:* Baby 
* NHI: ZKS330
* Gender: Female
* DOB: 2023-10-11
 
* GP 
* Facility ID: FZZ932-C
 
* PG1 
* Relationship Code: MTH
 

  * Expected outcome: 1. Input:Input: enrolment nomination information can be provided
1. Output:Output: Error EM13001 'Baby's NHI not found'

  * Mandatory: mandatory
* Reference: EnrolmentNomination-Error-3
  * Purpose: application will manage the error when attempting to send an enrolment nomination message that does not have the Baby’s date of birth
  * Input values: Send a nomination request for:* Baby 
* NHI: ZKS3307
* Gender: Female
* DOB: 'leave blank'
 
* GP 
* Facility ID: FZZ932-C
 
* PG1 
* Relationship Code: MTH
 

  * Expected outcome: 1. Input:Input: enrolment nomination information can be provided
1. Output:Output: Error EM13009 The baby's date of birth is missing or invalid.

  * Mandatory: mandatory
* Reference: EnrolmentNomination-Error-4
  * Purpose: application will manage the error when attempting to send an enrolment nomination message that has a Baby’s date of birth as a future date
  * Input values: Send a nomination request for:* Baby 
* NHI: ZKS3307
* Gender: Female
* DOB: 2025-10-11
 
* GP 
* Facility ID: FZZ932-C
 
* PG1 
* Relationship Code: MTH
 

  * Expected outcome: 1. Input:Minimum set of nomination information can be provided
1. Output: Error EM13009 The baby's date of birth is missing or invalid.

  * Mandatory: mandatory
* Reference: EnrolmentNomination-Error-5
  * Purpose: application will manage the error when attempting to send an enrolment nomination message that does not have the Baby’s gender
  * Input values: Send a nomination request for:* Baby 
* NHI: ZKS3307
* Gender: 'leave blank'
* DOB: 2023-10-11
 
* GP 
* Facility ID: FZZ932-C
 
* PG1 
* Relationship Code: MTH
 

  * Expected outcome: 1. Input: Enrolment nomination information can be provided
1. Output: Error EM13008 The baby's gender is missing or invalid.

  * Mandatory: mandatory
* Reference: EnrolmentNomination-Error-6
  * Purpose: application will manage the error when attempting to send an enrolment nomination message that has an incorrect baby gender
  * Input values: Send a nomination request for:* Baby 
* NHI: ZKS3307
* Gender: 'Mixed'
* DOB: 2023-10-11
 
* GP 
* Facility ID: FZZ932-C
 
* PG1 
* Relationship Code: MTH
 

  * Expected outcome: 1. Input: Enrolment nomination information can be provided
1. Output: Error 422 Unprocessable entity.

  * Mandatory: mandatory
* Reference: EnrolmentNomination-Error-7
  * Purpose: application will manage the error when attempting to send an enrolment nomination message with a gender that does not match the NHI
  * Input values: Send a nomination request for:* Baby 
* NHI: ZKS3307
* Gender: male
* DOB: 2023-10-11
 
* GP 
* Facility ID: FZZ932-C
 
* PG1 
* Relationship Code: MTH
 

  * Expected outcome: 1. Input: Enrolment nomination information can be provided
1. Output: Error EM13006 The provided gender does not match the NHI record for the baby.

  * Mandatory: mandatory
* Reference: EnrolmentNomination-Error-8
  * Purpose: application will manage the error when attempting to send an enrolment nomination message that does not have the Nominated GP facility ID
  * Input values: Send a nomination request for:* Baby 
* NHI: ZKS3307
* Gender: female
* DOB: 2023-10-11
 
* GP 
* Facility ID: 'leave empty'
 
* PG1 
* Relationship Code: MTH
 

  * Expected outcome: 1. Input: Enrolment nomination information can be provided
1. Output: Error EM13004 No nominated clinic has been provided.

  * Mandatory: mandatory
* Reference: EnrolmentNomination-Error-9
  * Purpose: application will manage the error when attempting to send an enrolment nomination message with an incorrect Nominated GP facility ID
  * Input values: Send a nomination request for:* Baby 
* NHI: ZKS3307
* Gender: female
* DOB: 2023-10-11
 
* GP 
* Facility ID: FZZ932-A
 
* PG1 
* Relationship Code: MTH
 

  * Expected outcome: 1. Input: Enrolment nomination information can be provided
1. Output: Error EM13005 The nominated clinic provided cannot be found in HPI.

  * Mandatory: mandatory
* Reference: EnrolmentNomination-Error-10
  * Purpose: application will manage the error when attempting to send an enrolment nomination message with a date of birth that does not match the NHI
  * Input values: Send a nomination request for:* Baby 
* NHI: ZKS3307
* Gender: female
* DOB: 2023-11-11
 
* GP 
* Facility ID: FZZ932-C
 
* PG1 
* Relationship Code: MTH
 

  * Expected outcome: 1. Input: Enrolment nomination information can be provided
1. Output: EM13007 The provided date of birth does not match the NHI record for the baby.

  * Mandatory: mandatory
* Reference: EnrolmentNomination-Error-11
  * Purpose: application will manage the error when attempting to send an enrolment nomination message without a mandatory resource
  * Input values: Send a nomination request without a:* Baby
* GP
* Next of kin

  * Expected outcome: 1. Input: Enrolment nomination information can be provided
1. Output: Error 422 Unprocessable entity.

  * Mandatory: mandatory
* Reference: EnrolmentNomination-Error-12
  * Purpose: application will manage the error when attempting to send an enrolment nomination with an incorrect next of kin relationship code
  * Input values: Send a nomination request for:* Baby 
* NHI: ZKS3307
* Gender: female
* DOB: 2023-10-11
 
* GP 
* Facility ID: FZZ932-C
 
* PG1 
* Relationship Code: MOTH
 

  * Expected outcome: 1. Input: Enrolment nomination information can be provided
1. Output: Error 422 Unprocessable entity.

  * Mandatory: mandatory
* Reference: EnrolmentNomination-Error-13
  * Purpose: application will manage the error when attempting to send an enrolment nomination for a baby that already has an active unexpired enrolment in the Natentiona Enrolment service
  * Input values: Send a nomination request for:* Baby 
* NHI: ZDS3946 
* Gender: other
* DOB: 1998-07-07
 
* GP 
* Facility ID: FZZ932-C
 
* PG1 
* Relationship Code: MTH
 

  * Expected outcome: 1. Input: Enrolment nomination information can be provided
1. Output: EEM13002 The baby is already enrolled or pre-enrolled in NES.

  * Mandatory: mandatory
* Reference: EnrolmentNomination-Error-14
  * Purpose: application will manage the error when attempting to send an enrolment nomination for a baby that has a deceased date
  * Input values: Send a nomination request for:* Baby 
* NHI: ZBQ2770 
* Gender: female
* DOB: 1979-01-01
 
* GP 
* Facility ID: FZZ932-C
 
* PG1 
* Relationship Code: MTH
 

  * Expected outcome: 1. Input: Enrolment nomination information can be provided
1. Output: EM13003 The baby has been marked as deceased in NHI.

  * Mandatory: mandatory

